(function(){
'use strict';
const model = (function(){

const PARTS={
 ears:[{name:'经典垂耳',v:['U','U'],family:'classic'},{name:'软团垂耳',v:['૮₍ ',' ₎ა'],family:'soft'},{name:'卷卷耳朵',v:['૮꒰ ',' ꒱ა'],family:'soft'},{name:'小括号耳',v:['૮( ',' )ა'],family:'soft'},{name:'蓬松耳朵',v:['U꒰ ',' ꒱U'],family:'classic'},{name:'圆圆脸颊',v:['U( ',' )U'],family:'classic'},{name:'轻盈小狗',v:['ᑌ','ᑌ'],family:'classic'},{name:'小小垂耳',v:['૮ ',' ა'],family:'soft'}],
 eyes:[{name:'小豆豆',v:['•','•'],mood:'日常'},{name:'点点眼',v:['・','・'],mood:'日常'},{name:'开心眯眼',v:['˃','˂'],mood:'开心'},{name:'弯弯笑眼',v:['ᵔ','ᵔ'],mood:'开心'},{name:'困困闭眼',v:['˘','˘'],mood:'困困'},{name:'软软低头',v:['ᴗ','ᴗ'],mood:'困困'},{name:'晕乎乎',v:['@','@'],mood:'委屈'},{name:'泪汪汪',v:['o̴̶̷᷄','o̴̶̷̥᷅'],mood:'委屈'},{name:'坚定小狗',v:['•̀','•́'],mood:'开心'},{name:'闪闪眼',v:['✧','✧'],mood:'开心'},{name:'圆眼睛',v:['ㅇ','ㅇ'],mood:'日常'},{name:'眨眨眼',v:['•','˘'],mood:'撒娇'}],
 mouth:[{name:'小狗嘴',v:'ﻌ'},{name:'小猫嘴',v:'ω'},{name:'笑一笑',v:'ᴗ'},{name:'软软嘴',v:'꒳'},{name:'嘟嘟嘴',v:'⤙'},{name:'小小吻',v:'⤚'},{name:'呜呜',v:'ᯅ'},{name:'小鼻尖',v:'ᴥ'},{name:'圆圆嘴',v:'ㅅ'},{name:'轻轻笑',v:'ᵕ'},{name:'小小点',v:'·̫'},{name:'吐舌头',v:'ڡ'}],
 decor:[{name:'素颜小狗',v:['','','','']},{name:'红扑扑',v:['','˶','˶','']},{name:'送你小心心',v:['','˶','˶',' ♡']},{name:'伸出小爪',v:['','','',' っ']},{name:'星星陪伴',v:['✧ ','','',' ✧']},{name:'困困 Zzz',v:['','','',' z Z']},{name:'戴小蝴蝶结',v:['୨୧ ','˶','˶','']},{name:'闪亮小狗',v:['˚₊ ','','',' ₊˚']}]
};
// Append-only preset indexes preserve every previously saved puppy.
PARTS.ears.push({name:'圆脸天使',v:['( ',' )'],family:'soft',spacing:''},{name:'小方脸',v:['[ ',' ]'],family:'soft'},{name:'圆滚滚',v:['（','）'],family:'soft'},{name:'小尖耳',v:['ฅ՞','՞ฅ'],family:'soft'});
PARTS.eyes.push(...[
 ['小小不开心','-','-','委屈'],['温柔弯眼','ˊ','ˋ','撒娇'],['笑弯了','^','^','开心'],['豆豆眨眼','･','<','撒娇'],['爱心眼','♡','♡','撒娇'],['委屈垂眼','；','；','委屈'],['眼泪啪嗒','T','T','委屈'],['紧张小狗','ó','ò','委屈'],['偷偷瞄你','¬','¬','日常'],['呆呆小狗','º','º','日常'],['月牙眼','⌒','⌒','开心'],['睁大眼睛','⊙','⊙','日常'],['瞌睡横线','–','–','困困'],['认真盯盯','•̀','ᴗ','开心'],['星星眼','★','★','开心'],['乖乖点头','ᵕ','ᵕ','撒娇'],['困到融化','ᓀ','ᓀ','困困'],['猫猫亮眼','✦','✦','开心']
].map(([name,a,b,mood])=>({name,v:[a,b],mood})));
PARTS.mouth.push(...[['小海鸥嘴','﹏'],['委屈扁嘴','︿'],['亲亲小嘴','3'],['乖乖抿嘴','⩊'],['张大嘴','O'],['小小圆嘴','o'],['猫猫笑','w'],['平平嘴巴','_'],['微微嘟嘴','ε'],['惊讶小狗','Ⱉ'],['软软鼻子','ᴓ'],['小小微笑','υ']].map(([name,v])=>({name,v})));
PARTS.decor.push(...[{name:'害羞斜线',v:['','//','//','']},{name:'小脸红红',v:['','⸝⸝','⸝⸝','']},{name:'举起爪爪',v:['ฅ ','','',' ฅ']},{name:'捧着心心',v:['','','',' つ♡']},{name:'一朵小花',v:['✿ ','','','']},{name:'星星点点',v:['⋆ ','','',' ⋆']}]);
const ACCESSORIES={
 horns:[{name:'不戴角',v:['','']},{name:'小恶魔角',v:['^ ','^ ']},{name:'尖尖恶魔角',v:['ψ ',' ψ']},{name:'弯弯小角',v:['⌁ ',' ⌁']},{name:'双尖小角',v:['˄ ',' ˄']}],
 tail:[{name:'不加尾巴',v:''},{name:'恶魔箭尾',v:' ↝'},{name:'爱心恶魔尾',v:' ⤳❥'},{name:'空心爱心尾',v:' ⤳♡'},{name:'卷卷尾巴',v:' ʚ'},{name:'翘翘小尾巴',v:' ⤤'},{name:'长长小尾巴',v:' 〜'},{name:'小爱心尾',v:' ⤳ღ'},{name:'小翘线尾',v:' ⸍'},{name:'招手尾巴',v:' ﾉ'}],
 wings:[{name:'不戴翅膀',v:['','']},{name:'扑扇天使翼',v:['⁽⁽ଘ','ଓ⁾⁾']},{name:'小天使翅膀',v:['ଘ','ଓ']},{name:'圆圆天使翼',v:['ʚ','ɞ']},{name:'展开小翅膀',v:['ଘ ',' ଓ']},{name:'星星天使翼',v:['✧ଘ','ଓ✧']}]
};
// Version 3: user-provided faces; indexes are append-only for old favorites.
const NEW_PARTS={ears:[],eyes:[],mouth:[],decor:[]};
function addPart(key,item){const index=PARTS[key].push(item)-1;NEW_PARTS[key].push(index);return index}
const freshEyes=[['半眯审视','≖','≖','日常'],['圆圆亮眼','◕','◕','开心'],['眼泪汪汪','˃̣̣̥','˂̣̣̥','委屈'],['懒懒半睁','⩌','⩌','困困'],['瀑布眼泪','ㅠ','ㅠ','委屈'],['咧嘴笑眼','ᗜ','ᗜ','开心'],['趴着睡觉','_','_','困困']].map(([name,l,r,mood])=>addPart('eyes',{name,v:[l,r],mood}));
const freshMouths=[['小小猫鼻','༝'],['委屈小尖嘴','‸'],['困困小嘴','⌯'],['调皮小舌头','𐃷'],['趴睡小鼻子','   ̫ ']].map(([name,v])=>addPart('mouth',{name,v}));
const freshEars=[['猫猫尖耳',['ᐢ','ᐢ']],['细细猫耳',['՞','՞']],['无框小脸',['','']],['趴睡圆脸',['(՞','՞)']]].map(([name,v])=>addPart('ears',{name,v,family:'soft',spacing:''}));
const sleepingDecor=addPart('decor',{name:'小小呼噜泡',v:['','','','ᐝ']});
const curlyTail=ACCESSORIES.tail.push({name:'小卷尾',v:'ಣ'})-1;
const FRESH_LOOKS=[
 {name:'半眯眼小狗',expected:'૮₍ ˶≖ ﻌ ≖˶ ₎ა',state:{ears:1,eyes:freshEyes[0],mouth:0,decor:1}},
 {name:'圆眼开心狗',expected:'૮₍ ˶◕ ᴗ ◕˶ ₎ა',state:{ears:1,eyes:freshEyes[1],mouth:2,decor:1}},
 {name:'泪汪汪小狗',expected:'૮₍ ˃̣̣̥ ᯅ ˂̣̣̥ ₎ა',state:{ears:1,eyes:freshEyes[2],mouth:6,decor:0}},
 {name:'害羞小猫',expected:'ᐢ⸝⸝•༝•⸝⸝ᐢ',state:{ears:freshEars[0],eyes:0,mouth:freshMouths[0],decor:9}},
 {name:'小猫委屈了',expected:'՞⩌ ‸ ⩌՞',state:{ears:freshEars[1],eyes:freshEyes[3],mouth:freshMouths[1],decor:0,spacing:' '}},
 {name:'懒懒小猫',expected:'՞⩌⌯⩌՞',state:{ears:freshEars[1],eyes:freshEyes[3],mouth:freshMouths[2],decor:0}},
 {name:'眼泪面条',expected:'ㅠ⩊ㅠ',state:{ears:freshEars[2],eyes:freshEyes[4],mouth:15,decor:0}},
 {name:'调皮卷尾',expected:'˶ᗜ𐃷ᗜ˶ಣ',state:{ears:freshEars[2],eyes:freshEyes[5],mouth:freshMouths[3],decor:1,accessories:{horns:0,tail:curlyTail,wings:0}}},
 {name:'趴着呼噜',expected:'(՞_   ̫ _՞)ᐝ',state:{ears:freshEars[3],eyes:freshEyes[6],mouth:freshMouths[4],decor:sleepingDecor}}
];
// Zizishou experiment: append new ear pairs; never renumber existing presets or favorites.
const NEW_ANIMAL_EARS=[
  {name:'兔兔长耳',v:['／(ᐢ ',' ᐢ)＼'],animal:'rabbit',spacing:''},
  {name:'兔兔软耳',v:['૮(ᐢ ',' ᐢ)ა'],animal:'rabbit',spacing:''},
  {name:'熊熊圆耳',v:['ʕ ',' ʔ'],animal:'bear',spacing:' '},
  {name:'小熊抱抱',v:['ʕっ ',' っʔ'],animal:'bear',spacing:' '},
  {name:'狐狸尖耳',v:['ฅ^','^ฅ'],animal:'fox',spacing:''},
  {name:'狐狸蓬蓬',v:['ᐢ⸝ ',' ⸝ᐢ'],animal:'fox',spacing:''},
  {name:'仓鼠团团',v:['꒰ ',' ꒱'],animal:'hamster',spacing:' '},
  {name:'仓鼠鼓腮',v:['(⸝⸝ ',' ⸝⸝)'],animal:'hamster',spacing:''}
];
PARTS.ears.push(...NEW_ANIMAL_EARS);
const ANIMALS=[
  {id:'dog',name:'小狗',earIndex:1,mouthIndex:0},
  {id:'cat',name:'小猫',earIndex:12,mouthIndex:24},
  {id:'rabbit',name:'兔兔',earIndex:16,mouthIndex:9},
  {id:'bear',name:'熊熊',earIndex:18,mouthIndex:7},
  {id:'fox',name:'狐狸',earIndex:20,mouthIndex:1},
  {id:'hamster',name:'仓鼠',earIndex:22,mouthIndex:15}
];
function animalForEar(index){
  if(!Number.isInteger(index)||index<0||index>=PARTS.ears.length)return null;
  return PARTS.ears[index].animal||([11,12,13].includes(index)?'cat':'dog');
}
const DEFAULT={ears:1,eyes:0,mouth:0,decor:1,custom:{},accessories:{horns:0,tail:0,wings:0,hands:0}};
const FAVORITES_KEY='puppy-factory:favorites';
function hasOwn(object,key){return Object.prototype.hasOwnProperty.call(object,key)}
function partValue(value,fallback){return value==null?fallback:value}
function cloneState(s){
  return Object.assign({},s,{
    custom:Object.assign({},s.custom),
    accessories:Object.assign({horns:0,tail:0,wings:0,hands:0},s.accessories)
  });
}
// 2026-11-23 界（拾提）：带脸框的耳朵（如 ૮(ᐢ ）拆成三块：外耳、脸边、内侧，可以只删里面的小耳朵
const EAR_FRAMES=new Set(['(',')','₍','₎','꒰','꒱','[',']','（','）','ʕ','ʔ']);
function earPieces(str,side){
  const chars=Array.from(str);
  const left=side==='left';
  const step=left?1:-1;
  let i=left?0:chars.length-1;
  while(i>=0&&i<chars.length&&!EAR_FRAMES.has(chars[i]))i+=step;
  if(i<0||i>=chars.length)return null;
  const before=chars.slice(0,i).join('');
  const frame=chars[i];
  const after=chars.slice(i+1).join('');
  return left?{outer:before,frame,inner:after}:{inner:before,frame,outer:after};
}
const EAR_SEGMENTS={
  left:[['leftOuter','outer'],['leftFrame','frame'],['leftInner','inner']],
  right:[['rightInner','inner'],['rightFrame','frame'],['rightOuter','outer']]
};
function earSegments(custom,ear,side){
  const base=ear.v[side==='left'?0:1];
  if(custom[side]!==undefined)return [[side,custom[side]]];
  const pieces=earPieces(base,side);
  if(!pieces)return [[side,base]];
  return EAR_SEGMENTS[side].map(([key,piece])=>[key,partValue(custom[key],pieces[piece])]);
}
function joinSegments(segments){return segments.map(([,text])=>text).join('')}
function faceValues(s,custom){
  const eyes=PARTS.eyes[s.eyes].v;
  const decor=PARTS.decor[s.decor].v;
  return {
    eyeLeft:partValue(custom.eyeLeft,eyes[0]),
    eyeRight:partValue(custom.eyeRight,eyes[1]),
    mouth:partValue(custom.mouth,PARTS.mouth[s.mouth].v),
    prefix:partValue(custom.prefix,decor[0]),
    blushLeft:partValue(custom.blushLeft,decor[1]),
    blushRight:partValue(custom.blushRight,decor[2]),
    suffix:partValue(custom.suffix,decor[3])
  };
}
function values(s){
  const custom=s.custom||{};
  const ear=PARTS.ears[s.ears];
  return Object.assign({
    left:joinSegments(earSegments(custom,ear,'left')),
    right:joinSegments(earSegments(custom,ear,'right'))
  },faceValues(s,custom));
}
function trimEarEdge(segments,edge){
  const fromStart=edge==='start';
  for(const segment of fromStart?segments:[...segments].reverse()){
    segment[1]=segment[1].replace(fromStart?/^\s+/u:/\s+$/u,'');
    if(segment[1])return;
  }
}
function faceSpacing(s){
  const ear=PARTS.ears[s.ears];
  return partValue(s.spacing,partValue(ear.spacing,ear.family==='classic'?'':' '));
}
function handParts(accessories,custom){
  const index=accessories.hands||0,item=(ACCESSORIES.hands||[])[index];
  if(!index||!item)return {outside:false,inside:false};
  const inside=item.pos==='in';
  return {outside:!inside,inside,left:partValue(custom.handLeft,item.v[0]),right:partValue(custom.handRight,item.v[1])};
}
// 抱在里面的手：有脸框就塞在脸框里面（ʕっ ・ᴥ・ っʔ），没有脸框就贴着耳朵内侧。
function insertInside(segments,hand,side){
  const frame=segments.findIndex(([key])=>key===side+'Frame');
  if(frame>=0)segments.splice(side==='left'?frame+1:frame,0,hand);
  else if(side==='left')segments.push(hand);
  else segments.unshift(hand);
}
function composeParts(s){
  const custom=s.custom||{};
  const accessories=s.accessories||{};
  const ear=PARTS.ears[s.ears];
  const face=faceValues(s,custom);
  const gap=faceSpacing(s);
  const left=earSegments(custom,ear,'left');
  const right=earSegments(custom,ear,'right');
  const horns=ACCESSORIES.horns[accessories.horns||0].v;
  const wings=ACCESSORIES.wings[accessories.wings||0].v;
  const tail=ACCESSORIES.tail[accessories.tail||0].v;
  // 2026-11-23 拾：手从耳朵和装饰里拆出来，单独一个零件。举在外面的贴着耳朵外侧，抱在里面的贴着脸框内侧。
  const hand=handParts(accessories,custom);
  if(hand.inside){insertInside(left,['handLeft',hand.left],'left');insertInside(right,['handRight',hand.right],'right')}
  if(accessories.horns){
    trimEarEdge(left,'end');
    trimEarEdge(right,'start');
  }
  return [
    ['prefix',face.prefix],
    ['wingLeft',accessories.wings?partValue(custom.wingLeft,wings[0]):''],
    ...(hand.outside?[['handLeft',hand.left]]:[]),
    ...left,
    ['hornLeft',accessories.horns?partValue(custom.hornLeft,horns[0]):''],
    ['blushLeft',face.blushLeft],
    ['eyeLeft',face.eyeLeft],
    ['leftGap',gap],
    ['mouth',face.mouth],
    ['rightGap',gap],
    ['eyeRight',face.eyeRight],
    ['blushRight',face.blushRight],
    ['hornRight',accessories.horns?partValue(custom.hornRight,horns[1]):''],
    ...right,
    ...(hand.outside?[['handRight',hand.right]]:[]),
    ['wingRight',accessories.wings?partValue(custom.wingRight,wings[1]):''],
    ['tail',accessories.tail?partValue(custom.tail,tail):''],
    ['suffix',face.suffix]
  ];
}
function compose(s){return joinSegments(composeParts(s))}
function randomState(family=null,mood=null,rng=Math.random){const pick=a=>a[Math.floor(rng()*a.length)];const indexes=(key,fn)=>PARTS[key].map((v,i)=>({v,i})).filter(x=>!x.v.hidden&&(!fn||fn(x.v))).map(x=>x.i);return {ears:pick(indexes('ears',family?v=>v.family===family:null)),eyes:pick(indexes('eyes',mood?v=>v.mood===mood:null)),mouth:pick(indexes('mouth')),decor:pick(indexes('decor')),custom:{}}}
// Random and ready-made little creatures share the same existing Unicode composer.
function randomAnimalState(animalId,mood=null,rng=Math.random){
  const animal=ANIMALS.find(a=>a.id===animalId);
  if(!animal)throw new RangeError('Unknown animal: '+animalId);
  const state=randomState(null,mood,rng);
  // 2026-11-23 拾：打了 noRandom 的耳朵（两对耳朵的 ૮(ᐢ ᐢ)ა、她不想随机到的长耳）随机时不抽；用户自己选照样能用。
  const allEars=PARTS.ears.map((_,i)=>i).filter(i=>animalForEar(i)===animalId);
  const ears=allEars.filter(i=>!PARTS.ears[i].noRandom).length?allEars.filter(i=>!PARTS.ears[i].noRandom):allEars;
  state.ears=ears[Math.min(ears.length-1,Math.floor(rng()*ears.length))];
  state.mouth=animal.mouthIndex;
  // 2026-11-23 界（拾发现「四个爪爪」）：耳朵里已经带了 ฅ 之类的字，随机时就不再配同样字的装饰，免得重复
  const earChars=new Set(Array.from(PARTS.ears[state.ears].v.join('')).filter(ch=>ch.trim()&&!/[()₍₎\[\]]/u.test(ch)));
  // 2026-11-23 拾：耳朵里带手（っ ฅ ／＼ o( )o）时，也不配带手的装饰。只管随机，用户自己拼不拦。
  const earHands=!!PARTS.ears[state.ears].hands;
  const clashes=i=>(earHands&&!!PARTS.decor[i].hands)||Array.from(PARTS.decor[i].v.join('')).some(ch=>earChars.has(ch));
  if(clashes(state.decor)){const ok=PARTS.decor.map((_,i)=>i).filter(i=>!clashes(i));if(ok.length)state.decor=ok[Math.floor(rng()*ok.length)]}
  return state;
}
const ANIMAL_LOOKS=ANIMALS.map(animal=>({
  id:animal.id,name:animal.name+'团子',
  state:Object.assign(cloneState(DEFAULT),{ears:animal.earIndex,mouth:animal.mouthIndex})
}));
function validState(s){return !!s&&(s.spacing===undefined||s.spacing===''||s.spacing===' ')&&['ears','eyes','mouth','decor'].every(k=>Number.isInteger(s[k])&&s[k]>=0&&s[k]<PARTS[k].length)&&(!s.accessories||(typeof s.accessories==='object'&&Object.entries(s.accessories).every(([k,v])=>hasOwn(ACCESSORIES,k)&&Number.isInteger(v)&&v>=0&&v<ACCESSORIES[k].length)))&&(!s.custom||Object.entries(s.custom).every(([k,v])=>['left','right','eyeLeft','eyeRight','mouth','prefix','suffix','blushLeft','blushRight','hornLeft','hornRight','wingLeft','wingRight','tail','leftOuter','leftFrame','leftInner','rightInner','rightFrame','rightOuter','handLeft','handRight'].includes(k)&&typeof v==='string'&&Array.from(v).length<=16&&!/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/u.test(v)))}
function readFavorites(storage){try{const data=JSON.parse(storage.getItem(FAVORITES_KEY)||'[]');return Array.isArray(data)?data.filter(validState).slice(0,500).map(cloneState):[]}catch(error){return []}}
function writeFavorites(storage,list){try{storage.setItem(FAVORITES_KEY,JSON.stringify(list));return true}catch(error){return false}}

// 2026-11-23 界（拾说「你现在用的这个也好可爱」）：把 ٩(ˊᗜˋ*)و 拆成零件加进来，只往后追加，不改已有编号
const cheerEyes=addPart('eyes',{name:'弯弯笑眼',v:['ˊ','ˋ'],mood:'开心'});
const cheerMouth=addPart('mouth',{name:'张嘴大笑',v:'ᗜ'});
const tightEars=addPart('ears',{name:'紧凑圆脸',v:['(',')'],family:'soft',spacing:''});
const cheerDecor=addPart('decor',{name:'举手欢呼',v:['٩','','*','و']});
FRESH_LOOKS.push({name:'欢呼团子',expected:'٩(ˊᗜˋ*)و',state:{ears:tightEars,eyes:cheerEyes,mouth:cheerMouth,decor:cheerDecor,spacing:''}});

// 2026-11-23 界（拾：「加个这个气气素材好不好？」૮₍ꐦ˶•᷅ ﻌ •᷄˶₎ა）：拆成零件，只往后追加，不改已有编号
const angryEyes=addPart('eyes',{name:'皱眉豆豆眼',v:['•᷅','•᷄'],mood:'生气'});
const snugSoftEars=addPart('ears',{name:'软团贴脸',v:['૮₍','₎ა'],family:'soft',spacing:' '});
const angryDecor=addPart('decor',{name:'气鼓鼓',v:['','ꐦ˶','˶','']});
FRESH_LOOKS.push({name:'气气团子',expected:'૮₍ꐦ˶•᷅ ﻌ •᷄˶₎ა',state:{ears:snugSoftEars,eyes:angryEyes,mouth:0,decor:angryDecor}});

// 2026-11-23 界（拾丢来一串 12 只：「按照我们的 live 2d 的形式切分塞到素材里」）：只往后追加，不改已有编号。
// (◍•ᴗ•◍)❤ 的 ❤ 在 iOS/微信会变彩色 emoji，换成 ♡。
const padMouth=addPart('mouth',{name:'肉垫小嘴',v:'ࡇ'});
const pointMouth=addPart('mouth',{name:'尖尖小嘴',v:'^'});
const waveMouth=addPart('mouth',{name:'波浪小嘴',v:'~'});
const boxMouth=addPart('mouth',{name:'小方嘴',v:'⌔'});
// 憋泪小猫的嘴两边要两个空格，但收藏只认 '' 或 ' ' 的间距，所以把多出的空格放进嘴里（同「趴睡小鼻子」的做法）。
const wideSulkMouth=addPart('mouth',{name:'憋住的小尖嘴',v:' ‸ '});
const smugEyes=addPart('eyes',{name:'挑眉眯眼',v:['-̀','-́'],mood:'日常'});
const softEyes=addPart('eyes',{name:'软软眯眼',v:['´͈','`͈'],mood:'撒娇'});
const huffEyes=addPart('eyes',{name:'鼓气斜眼',v:['´','｀'],mood:'生气'});
const holdTearEyes=addPart('eyes',{name:'憋泪一线',v:['_','_ ̥'],mood:'委屈'});
const frownEyes=addPart('eyes',{name:'皱眉圆眼',v:['•︡','•︠'],mood:'委屈'});
const sobEyes=addPart('eyes',{name:'哭唧唧',v:['꒦ິ','꒦ິ'],mood:'委屈'});
const glowEyes=addPart('eyes',{name:'亮晶晶豆豆',v:['•͈','•͈'],mood:'撒娇'});
const rollEyes=addPart('eyes',{name:'翻白眼',v:['◔','◔'],mood:'日常'});
const fistEars=addPart('ears',{name:'握拳小手',v:['o(',')o'],family:'soft',spacing:''});
const cheekEars=addPart('ears',{name:'大圆脸蛋',v:['(O ',' O)'],family:'soft',spacing:' '});
const heartDecor=addPart('decor',{name:'小心心',v:['','','','♡']});
const ballDecor=addPart('decor',{name:'圆圆腮',v:['','◍','◍','']});
const ballHeartDecor=addPart('decor',{name:'圆腮比心',v:['','◍','◍','♡']});
const dotDecor=addPart('decor',{name:'小句点',v:['｡','','','｡']});
FRESH_LOOKS.push(
 {name:'肉垫笑笑狗',expected:'૮₍ ˶ᵕࡇᵕ˶ ₎ა',state:{ears:1,eyes:27,mouth:padMouth,decor:1,spacing:''}},
 {name:'挑眉小狗',expected:'૮₍ ˶-̀ ᴗ -́˶ ₎ა',state:{ears:1,eyes:smugEyes,mouth:2,decor:1}},
 {name:'软软比心',expected:'( ´͈ ᵕ `͈ )♡',state:{ears:8,eyes:softEyes,mouth:9,decor:heartDecor,spacing:' '}},
 {name:'鼓气包',expected:'o(´^｀)o',state:{ears:fistEars,eyes:huffEyes,mouth:pointMouth,decor:0}},
 {name:'憋泪小猫',expected:'ᐢ_  ‸  _ ̥ᐢ',state:{ears:12,eyes:holdTearEyes,mouth:wideSulkMouth,decor:0,spacing:' '}},
 {name:'皱眉委屈',expected:'•︡ᯅ•︠',state:{ears:14,eyes:frownEyes,mouth:6,decor:0}},
 {name:'哭唧唧',expected:'꒦ິ^꒦ິ',state:{ears:14,eyes:sobEyes,mouth:pointMouth,decor:0}},
 {name:'圆腮比心',expected:'(◍•ᴗ•◍)♡',state:{ears:24,eyes:0,mouth:2,decor:ballHeartDecor}},
 {name:'扑扑小天使',expected:'⁽⁽ଘ( ˊᵕˋ )ଓ⁾⁾',state:{ears:8,eyes:13,mouth:9,decor:0,accessories:{wings:1}}},
 {name:'大圆脸笑',expected:'(O ^ ~ ^ O)',state:{ears:cheekEars,eyes:14,mouth:waveMouth,decor:0}},
 {name:'亮晶晶',expected:'(◍•͈⌔•͈◍)',state:{ears:24,eyes:glowEyes,mouth:boxMouth,decor:ballDecor}},
 {name:'翻白眼',expected:'｡◔‸◔｡',state:{ears:14,eyes:rollEyes,mouth:25,decor:dotDecor}},
);

// 2026-11-23 拾：「左内侧、右内侧其实也是手」——给带手的零件偷偷打标签，随机时手不和手撞。
for(const i of [11,16,19,20,fistEars])PARTS.ears[i].hands=true;
for(const i of [3,10,11,15])PARTS.decor[i].hands=true;
// 2026-11-23 拾：「喜欢 ₍ᐢ ᐢ₎ 这种，不要长耳朵了」。
// 旧的两款兔耳留在零件库（收藏过的人不变样），但不进随机；兔兔默认换成软团兔耳。
const softBunnyEars=addPart('ears',{name:'兔兔团耳',v:['₍ᐢ ',' ᐢ₎'],animal:'rabbit',spacing:''});
const snugBunnyEars=addPart('ears',{name:'兔兔贴脸',v:['₍ᐢ','ᐢ₎'],animal:'rabbit',spacing:''});
PARTS.ears[16].noRandom=true;
PARTS.ears[17].noRandom=true;
ANIMALS.find(a=>a.id==='rabbit').earIndex=softBunnyEars;
ANIMAL_LOOKS.find(l=>l.id==='rabbit').state.ears=softBunnyEars;

// 2026-11-23 18:01 拾：评论区说「凸^-^凸 这个很可爱 贱贱的」，加进素材；库里已有的（^ 笑弯了）不重复加。
// 凸 是常用汉字，手机自带中文字体都有，不用另外打字体包。
const flipEars=addPart('ears',{name:'凸凸手',v:['凸','凸'],family:'soft',spacing:'',hands:true});
const dashMouth=addPart('mouth',{name:'一字小嘴',v:'-'});
FRESH_LOOKS.push({name:'贱贱团子',expected:'凸^-^凸',state:{ears:flipEars,eyes:14,mouth:dashMouth,decor:0}});

// 2026-11-23 18:29 拾：「分类有点乱，特别是耳朵和手……把手拆开放到耳朵装饰这一边」。
// 手单独做成一个零件（存在 accessories.hands，和角、尾巴、翅膀一样可以单独换）。
// 原来绑着手的耳朵、装饰都不删（收藏过的团子打开还是原样），只是从列表和随机里藏起来。
ACCESSORIES.hands=[
  {name:'不带手',v:['','']},
  {name:'举起爪爪',v:['ฅ','ฅ'],pos:'out'},
  {name:'凸凸手',v:['凸','凸'],pos:'out'},
  {name:'握拳小手',v:['o','o'],pos:'out'},
  {name:'欢呼小手',v:['٩','و'],pos:'out'},
  {name:'抱抱小手',v:['っ','っ'],pos:'in'},
  {name:'伸出小爪',v:['',' っ'],pos:'out'},
  {name:'捧着心心',v:['',' つ♡'],pos:'out'}
];
const HANDS={paws:1,flip:2,fist:3,cheer:4,hug:5,reach:6,heart:7};
const foxPointEars=addPart('ears',{name:'狐狸尖尖',v:['^','^'],animal:'fox',spacing:''});
const cheerStarDecor=addPart('decor',{name:'星星腮',v:['','','*','']});
for(const i of [11,19,20,fistEars,flipEars]){PARTS.ears[i].hidden=true;PARTS.ears[i].noRandom=true}
for(const i of [3,10,11,cheerDecor])PARTS.decor[i].hidden=true;
// 狐狸默认换成蓬蓬耳（不带手），按「狐狸」时和预览长得一样。
ANIMALS.find(a=>a.id==='fox').earIndex=21;
ANIMAL_LOOKS.find(l=>l.id==='fox').state.ears=21;
// 用到旧捆绑零件的现成造型，换成「干净耳朵 + 小手」，拼出来一字不差。
const withHands=(look,patch,hands)=>{Object.assign(look.state,patch);look.state.accessories=Object.assign({horns:0,tail:0,wings:0},look.state.accessories,{hands})};
withHands(FRESH_LOOKS.find(l=>l.name==='鼓气包'),{ears:tightEars},HANDS.fist);
withHands(FRESH_LOOKS.find(l=>l.name==='欢呼团子'),{decor:cheerStarDecor},HANDS.cheer);
withHands(FRESH_LOOKS.find(l=>l.name==='贱贱团子'),{ears:freshEars[2]},HANDS.flip);

// 2026-11-23 18:54 拾：想要 = = 这种眯眯眼；软软眯眼、亮晶晶豆豆也都留着。
addPart('eyes',{name:'眯眯眼',v:['=','='],mood:'撒娇'});

// 2026-11-23 19:18 拾：小猫、狐狸、兔兔都用 ᐢ，看着一样。
// 狐狸回到原来的 ฅ^ ^ฅ（干净尖耳 + 自动配的爪爪）；小猫换成大三角耳 /ᐠ ᐟ\（字体包 19，DejaVu Sans）。
const catTriEars=addPart('ears',{name:'猫猫三角耳',v:['/ᐠ','ᐟ\\'],animal:'cat',spacing:''});
ANIMALS.find(a=>a.id==='cat').earIndex=catTriEars;
ANIMAL_LOOKS.find(l=>l.id==='cat').state.ears=catTriEars;
const fox=ANIMALS.find(a=>a.id==='fox');fox.earIndex=foxPointEars;fox.hands=HANDS.paws;
Object.assign(ANIMAL_LOOKS.find(l=>l.id==='fox').state,{ears:foxPointEars,accessories:{horns:0,tail:0,wings:0,hands:HANDS.paws}});

// 2026-11-23 19:34 拾：狐狸是尖耳朵，ᐢ⸝ ⸝ᐢ 更像兔兔。
// 原「狐狸蓬蓬」原地改名「蓬松兔耳」、归到兔兔（字不变，收藏不变样）；另做尖尖的「蓬松狐耳」。
Object.assign(PARTS.ears[21],{name:'蓬松兔耳',animal:'rabbit'});
addPart('ears',{name:'蓬松狐耳',v:['^⸝ ',' ⸝^'],animal:'fox',spacing:''});
// 兔兔长耳去掉里面的小耳朵，只留外面的斜线，叫「垂耳兔」。旧的藏起来，收藏过的照旧。
addPart('ears',{name:'垂耳兔',v:['／( ',' )＼'],animal:'rabbit',spacing:''});
Object.assign(PARTS.ears[16],{hidden:true,noRandom:true});
// 拾 11-23 说过兔兔随机只要 ₍ᐢ ᐢ₎ 这种，新归来的两款兔耳只给自己挑，不进随机。
PARTS.ears[21].noRandom=true;PARTS.ears[PARTS.ears.length-1].noRandom=true;

// 2026-11-23 19:38 拾：OuO UuU OvO OAO OaO 这种字母脸。补字母嘴和 O、U 两种眼睛。
['小u嘴|u','小v嘴|v','大A嘴|A','小a嘴|a'].forEach(x=>{const [name,v]=x.split('|');addPart('mouth',{name,v})});
addPart('eyes',{name:'大O眼',v:['O','O'],mood:'日常'});
addPart('eyes',{name:'U形眼',v:['U','U'],mood:'困困'});

// 2026-11-24 00:42 拾发来一篮子新零件：可爱腮红、猫耳朵、右边装饰、眼镜、星星、蝴蝶结、四叶草。
// 查过都不重复。冷门字（⪩⪨ ⎚ ᨓ ྀི 𖧧 ꕤ ࣪ 等）另外打了字体包 20 号起。写法保持 ES2017，方便合进小工具版。
const earIndex=function(name){return PARTS.ears.findIndex(function(x){return x.name===name})};
const cuteBlush=addPart('decor',{name:'可爱腮红',v:['','๑','๑','']});
const dotMouth=addPart('mouth',{name:'小圆点嘴',v:'.'});
addPart('ears',{name:'尖尖猫耳',v:['⪩ ',' ⪨'],animal:'cat'});
addPart('decor',{name:'右边小撇撇',v:['','','','ˊˎ˗']});
addPart('decor',{name:'星星点点',v:['✩.*˚ ','','','']});
addPart('decor',{name:'四叶草',v:['','','',' ⋆𖧧˚🍀˚⊹ ࣪ ˖｡ꕤ']});
// 蝴蝶结 ྀི 是要贴在前一个字上的小符号，单独放会挂在空格上。照常见写法贴在脸框 ꒰ ꒱ 后面，做成一对耳朵。
const bowEars=addPart('ears',{name:'蝴蝶结团耳',v:['꒰ྀི ',' ꒱ྀི'],animal:'hamster'});
// 眼镜脸没有耳朵：做一个藏起来的「不带耳朵」，只给眼镜团子用，不进列表、不进随机。
const noEars=addPart('ears',{name:'不带耳朵',v:['',''],spacing:'',hidden:true,noRandom:true});
const squareGlasses=addPart('eyes',{name:'方框眼镜',v:['⎚','⎚'],mood:'日常'});
const armGlasses=addPart('eyes',{name:'带腿眼镜',v:['ˋ⎚','⎚ˊ'],mood:'日常'});
const glassesMouth=addPart('mouth',{name:'小波浪嘴',v:'ᨓ'});
FRESH_LOOKS.push(
 {name:'腮红团子',expected:'(๑• . •๑)',state:{ears:earIndex('紧凑圆脸'),eyes:0,mouth:dotMouth,decor:cuteBlush,spacing:' '}},
 {name:'眼镜团子',expected:'⎚ᨓ⎚',state:{ears:noEars,eyes:squareGlasses,mouth:glassesMouth,decor:0}},
 {name:'斯文团子',expected:'ˋ⎚⤚⎚ˊ',state:{ears:noEars,eyes:armGlasses,mouth:5,decor:0}},
 {name:'蝴蝶结团子',expected:'꒰ྀི ˶• ᴗ •˶ ꒱ྀི',state:{ears:bowEars,eyes:0,mouth:2,decor:1}}
);

return {PARTS, ACCESSORIES, NEW_PARTS, FRESH_LOOKS, ANIMALS, animalForEar, DEFAULT, FAVORITES_KEY, hasOwn, cloneState, EAR_FRAMES, earPieces, earSegments, values, faceSpacing, composeParts, compose, randomState, randomAnimalState, ANIMAL_LOOKS, validState, readFavorites, writeFavorites, HANDS};
}());

const i18n = (function(){
// Display text only: saved puppy states and Unicode faces stay language-neutral.
const LANGUAGE_KEY = 'puppy-factory:language';
const EN = {
  '弯弯笑眼': 'Crescent smile eyes', '张嘴大笑': 'Big laugh', '紧凑圆脸': 'Snug round face', '举手欢呼': 'Hands up cheer', '欢呼团子': 'Cheering dango',
  '皱眉豆豆眼': 'Frowny dot eyes', '软团贴脸': 'Snug soft ears', '气鼓鼓': 'Huffy cheeks', '气气团子': 'Huffy dango', '生气': 'Huffy',
  '不带手': 'No hands', '举起爪爪': 'Paws up', '握拳小手': 'Little fists', '欢呼小手': 'Cheering hands', '抱抱小手': 'Hugging hands', '伸出小爪': 'Reaching paw', '捧着心心': 'Holding a heart', '狐狸尖尖': 'Pointy fox ears', '星星腮': 'Star cheek', '小手': 'Hands', '举在外面，或者抱在怀里': 'Raised outside, or hugged inside', '左手': 'Left hand', '右手': 'Right hand',
  '凸凸手': 'Double flip-off', '一字小嘴': 'Flat dash mouth', '贱贱团子': 'Cheeky bun',
  '肉垫小嘴': 'Paw-pad mouth', '尖尖小嘴': 'Pointy mouth', '波浪小嘴': 'Wavy mouth', '小方嘴': 'Little square mouth', '憋住的小尖嘴': 'Held-in pout',
  '挑眉眯眼': 'Smug squint', '软软眯眼': 'Soft squint', '眯眯眼': 'Squinty =', '猫猫三角耳': 'Triangle cat ears', '小u嘴': 'Little u mouth', '小v嘴': 'Little v mouth', '大A嘴': 'Big A mouth', '小a嘴': 'Little a mouth', '大O眼': 'Big O eyes', 'U形眼': 'U eyes', '蓬松兔耳': 'Fluffy bunny ears', '蓬松狐耳': 'Fluffy fox ears', '垂耳兔': 'Lop-eared bunny', '鼓气斜眼': 'Huffy glance', '憋泪一线': 'Holding back tears', '皱眉圆眼': 'Frowny round eyes', '哭唧唧': 'Sobbing', '亮晶晶豆豆': 'Sparkly dots', '翻白眼': 'Eye roll',
  '可爱腮红': 'Cute blush', '小圆点嘴': 'Tiny dot mouth', '尖尖猫耳': 'Pointy cat ears', '右边小撇撇': 'Little flicks', '星星点点': 'Star sprinkles', '四叶草': 'Four-leaf clover', '蝴蝶结团耳': 'Ribbon bun ears', '不带耳朵': 'No ears', '方框眼镜': 'Square glasses', '带腿眼镜': 'Glasses with arms', '小波浪嘴': 'Wavy mouth', '腮红团子': 'Blushing bun', '眼镜团子': 'Glasses bun', '斯文团子': 'Scholarly bun', '蝴蝶结团子': 'Ribbon bun',
  '握拳小手': 'Little fists', '大圆脸蛋': 'Big round cheeks', '小心心': 'Little heart', '圆圆腮': 'Round cheeks', '圆腮比心': 'Round cheeks + heart', '小句点': 'Tiny dots', '兔兔团耳': 'Soft bunny ears', '兔兔贴脸': 'Snug bunny ears',
  '肉垫笑笑狗': 'Paw-pad grin pup', '挑眉小狗': 'Smug pup', '软软比心': 'Soft heart', '鼓气包': 'Huffy bun', '憋泪小猫': 'Teary kitty', '皱眉委屈': 'Frowny pout', '扑扑小天使': 'Fluttering angel', '大圆脸笑': 'Big round grin', '亮晶晶': 'Sparkly',
  '左外耳': 'Left outer ear', '左脸边': 'Left face edge', '左内侧': 'Left inner', '右内侧': 'Right inner', '右脸边': 'Right face edge', '右外耳': 'Right outer ear',
  '⇪ 卡片': '⇪ Card', '生成分享卡片': 'Make a share card', '⇪ 分享卡片': '⇪ Share card',
  '长按图片保存，或者点下面的按钮。卡片下面有二维码，朋友扫一下就能来捏。': 'Long-press to save, or use the buttons below. Friends can scan the QR code to make their own.',
  '字字兽分享卡片': 'ZiZiShou share card', '保存图片': 'Save image', '分享': 'Share', '关闭': 'Close',
  '字字兽 · 颜文字团子工厂': 'ZiZiShou · Kaomoji Studio', '自由组合颜文字字符，随时组合你喜欢的颜文字，以及部分改动表情': 'Mix kaomoji characters freely, build the faces you love, and tweak any part of the expression',
  '小爱心尾': 'Little heart tail', '小翘线尾': 'Tiny flick tail', '招手尾巴': 'Waving tail',
  '扫码捏一只你的团子 →': 'Scan to make your own →', '卡片生成失败了，再试一次吧': 'Could not make the card. Please try again.', '字字兽': 'ZiZiShou',
  '好了': 'Done', '拆零件': 'Edit parts', '✂ 拆零件': '✂ Edit parts', '点一下，拆开零件': 'Tap to edit parts',
  '点 × 删掉不想要的那一块，点格子可以自己改字。删掉、改过的零件会一直保持，直到你在下面重新选这个部件。': 'Tap × to remove a piece, or tap a box to type your own. Removed and edited pieces stay until you pick that part again below.',
  '拆好啦，删掉的零件会一直保持': 'Done! Removed pieces will stay removed.', '↺ 恢复': '↺ Restore',
  '前装饰': 'Front deco', '后装饰': 'Back deco', '左翅膀': 'Left wing', '右翅膀': 'Right wing', '左耳': 'Left ear', '右耳': 'Right ear',
  '左角': 'Left horn', '右角': 'Right horn', '左腮红': 'Left blush', '右腮红': 'Right blush', '左眼': 'Left eye', '右眼': 'Right eye', '嘴巴': 'Mouth', '尾巴': 'Tail',
  'Puppy Factory · 小狗颜文字工厂': 'Puppy Factory · Kaomoji Studio',
  '小狗颜文字工厂': 'Little Kaomoji Studio',
  '捏一只属于你的小狗。自由组合耳朵、眼睛、嘴巴和装饰，一键复制可爱颜文字。': 'Make a puppy of your own. Mix ears, eyes, mouths and accessories, then copy your cute kaomoji.',
  'Puppy Factory 首页': 'Puppy Factory home',
  '主导航': 'Main navigation', '小狗工坊': 'Puppy Studio', '♡ 我的收藏': '♡ Favorites',
  '今天，想捏一只': 'What little creature', '什么小狗？': 'will you make today?',
  '一点软乎乎，一点小情绪。把可爱拼起来，带去每一次聊天。': 'A little fluff, a little feeling. Make something cute for every chat.',
  '颜文字编辑器': 'Kaomoji editor', '● 正在营业 · 快乐制造中': '● Open for tiny happy moments',
  '可爱': 'CUTE', '刚出炉的软乎乎小狗': 'A freshly made, fluffy little puppy',
  '▣ 复制小狗': '▣ Copy puppy', '♡ 收藏': '♡ Save', '♥ 已收藏': '♥ Saved',
  '小狗编辑操作': 'Puppy editing actions', '↶ 撤回': '↶ Undo', '⤨ 随机': '⤨ Random', '↺ 清空': '↺ Clear',
  '眼睛、嘴巴直接点选，配件可以叠加哦': 'Pick eyes and a mouth. Stack accessories, too!',
  '跳到零件分区': 'Jump to a part section', '眼睛': 'Eyes', '嘴巴': 'Mouth',
  '角·尾巴·翅膀': 'Accessories', '耳朵·装饰': 'Ears & extras',
  '捏捏你的小狗': 'Make your little puppy', '常用零件先看 8 个': '8 favorites first', '点上面的标签换一格，左右滑挑零件': 'Pick a tab above, then swipe for parts',
  '新到的小表情': 'Fresh little faces', '左右滑动 · 点一下就能继续捏': 'Swipe, tap, and make it yours',
  '一键穿搭': 'Ready-to-wear looks', '眼睛·嘴巴': 'Eyes · Mouth', '耳朵·装饰·爪爪': 'Ears · Decor · Paws', '选择要换的零件': 'Choose which part to change', '左右滑动看更多': 'Swipe for more', '选择小狗家族': 'Choose a puppy family',
  '只换耳朵，保留表情和配件': 'Change ears, keep the face and accessories',
  '脸部间距': 'Face spacing', '紧凑贴贴': 'Snug', '松软留白': 'Airy', '当前配方': 'Your recipe',
  '小狗集合啦': 'The puppy parade', '遇到喜欢的，就把它带走吧。': 'Find a favorite and take it along.',
  '小狗分类': 'Puppy categories', '再来一窝小狗 ⤨': 'Another litter ⤨',
  '收藏的小狗 ♡': 'Your saved puppies ♡', '住在这台设备、这个浏览器里。': 'Saved in this browser, on this device.',
  '这里等着你的小狗入住': 'A little home for your puppies', '点一下 ♡，就能把喜欢的小狗留在这里。': 'Tap ♡ to keep a little puppy here.',
  '去捏一只小狗': 'Make a puppy', '小狗负责可爱，你负责开心。': 'The puppies bring the cute. You bring the smiles.',
  '无需注册 · 收藏仅保存在本机 · 不同设备的字形可能略有差异': 'No sign-up · Saved locally · Glyphs may vary by device',
  '长按，把小狗带走': 'Press and hold to take your puppy',
  '浏览器暂时不允许自动复制，请选中下方文字手动复制。': 'Automatic copying is unavailable. Select the text below and copy it manually.',
  '待复制的小狗颜文字': 'Puppy kaomoji to copy', '完成': 'Done', '切换语言': 'Choose language',
  '小狗窝已经住满 500 只啦': 'Your puppy home is full: 500 saved puppies!',
  '浏览器无法保存收藏，请允许本地存储后再试': 'Saving is unavailable. Allow local storage and try again.',
  '♡ 小狗住进收藏夹啦': '♡ A puppy moved into your favorites!', '已从收藏中移出': 'Removed from favorites',
  '复制好啦！把小狗带去聊天吧 ♡': 'Copied! Take your puppy to a chat ♡',
  '空脸小狗 · 等待你选零件': 'A blank puppy · Pick some parts', '自定义': 'Custom',
  '空空的小狗脸，重新捏一只吧': 'A fresh little face, ready for your ideas',
  '天使小狗正在扑扇翅膀': 'A little angel puppy, fluttering its wings',
  '今天也是可爱的小恶魔': 'A cute little devil, just for today',
  '小狗困困，陪你慢慢休息': 'A sleepy puppy to rest beside you', '这一只，是你的独家小狗': 'This little puppy is uniquely yours',
  '选择眼睛': 'Choose eyes', '选择嘴巴': 'Choose a mouth', '换一对小耳朵': 'Choose ears', '腮红与小装饰': 'Blush & little extras',
  '左耳': 'Left ear', '右耳': 'Right ear', '左眼': 'Left eye', '右眼': 'Right eye',
  '前面的小装饰': 'Prefix', '后面的小装饰': 'Suffix',
  '自己输入眼睛': 'Type your own eyes', '自己输入嘴巴': 'Type your own mouth',
  '自己输入耳朵': 'Type your own ears', '自己输入前后装饰': 'Type your own prefix or suffix',
  '没有找到，试试换个名字，或展开下方自定义。': 'No matches. Try another name or type your own below.',
  '眼睛心情': 'Eye moods', '常用': 'Popular', '开心': 'Happy', '困': 'Sleepy', '哭': 'Teary', '坏笑': 'Cheeky', '害羞': 'Shy',
  '搜名字或符号：≖、困困、眼泪…': 'Search names or symbols: ≖, sleepy, tears…',
  '搜名字或符号：小舌头、猫鼻…': 'Search names or symbols: tongue, nose…',
  '收起，只看常用 ▴': 'Show fewer ▴', '展开全部 ▾': 'Show all ▾', '最近使用': 'Recently used',
  '角、尾巴与翅膀': 'Horns, tails & wings', '三种可以一起戴': 'Mix all three!',
  '天使翅膀': 'Angel wings', '小尾巴': 'Tails', '新到表情': 'New faces', '全部小狗': 'All puppies', '垂耳小狗': 'Floppy puppies',
  '软团小狗': 'Fluffy puppies', '小恶魔': 'Little devil', '小天使': 'Little angel',
  '日常': 'Everyday', '撒娇': 'Sweet', '困困': 'Sleepy', '委屈': 'Teary',
  '日常小狗': 'Everyday puppy', '开心小狗': 'Happy puppy', '撒娇小狗': 'Sweet puppy', '困困小狗': 'Sleepy puppy',
  '委屈小狗': 'Teary puppy', '天使小狗': 'Angel puppy', '恶魔小狗': 'Devil puppy',
  '垂耳系': 'Floppy', '软团系': 'Fluffy', '捏捏': 'Edit', '复制': 'Copy', '收藏': 'Save',
  '叮！一只新小狗诞生了': 'Ding! A new puppy is here!',
  '搭配已清空，点一下撤回就能找回来': 'Cleared! Tap Undo to bring it back.', '新的一窝小狗来啦': 'A fresh litter of puppies is here!',
  '摇尾小恶魔': 'Tail-wagging devil', '扑扇小天使': 'Fluttering angel', '困困抱抱': 'Sleepy cuddles',
  '半眯眼小狗': 'Side-eye puppy', '圆眼开心狗': 'Bright-eyed puppy', '泪汪汪小狗': 'Watery-eyed puppy',
  '害羞小猫': 'Shy kitten', '小猫委屈了': 'Pouting kitten', '懒懒小猫': 'Lazy kitten',
  '眼泪面条': 'Noodle tears', '调皮卷尾': 'Cheeky curly tail', '趴着呼噜': 'Sleepy purrs',
  '经典垂耳': 'Classic floppy', '软团垂耳': 'Fluffy floppy', '卷卷耳朵': 'Curly ears',
  '小括号耳': 'Bracket ears', '蓬松耳朵': 'Fluffy ears', '圆圆脸颊': 'Round cheeks',
  '轻盈小狗': 'Light floppy ears', '小小垂耳': 'Tiny floppy ears', '圆脸天使': 'Round angel face',
  '小方脸': 'Square face', '圆滚滚': 'Round face', '小尖耳': 'Pointy ears',
  '猫猫尖耳': 'Kitten ears', '细细猫耳': 'Tiny kitten ears', '无框小脸': 'Frameless face', '趴睡圆脸': 'Sleepy round face',
  '小豆豆': 'Bean eyes', '点点眼': 'Dot eyes', '开心眯眼': 'Happy squint', '弯弯笑眼': 'Smiling eyes',
  '困困闭眼': 'Sleepy eyes', '软软低头': 'Soft closed eyes', '晕乎乎': 'Dizzy eyes', '泪汪汪': 'Watery eyes',
  '坚定小狗': 'Determined eyes', '闪闪眼': 'Sparkle eyes', '圆眼睛': 'Round eyes', '眨眨眼': 'Wink',
  '小小不开心': 'Little pout', '温柔弯眼': 'Gentle eyes', '笑弯了': 'Happy arches', '豆豆眨眼': 'Bean wink',
  '爱心眼': 'Heart eyes', '委屈垂眼': 'Droopy tears', '眼泪啪嗒': 'Falling tears', '紧张小狗': 'Nervous eyes',
  '偷偷瞄你': 'Sneaky glance', '呆呆小狗': 'Dazed eyes', '月牙眼': 'Crescent eyes', '睁大眼睛': 'Wide eyes',
  '瞌睡横线': 'Sleepy lines', '认真盯盯': 'Focused gaze', '星星眼': 'Star eyes', '乖乖点头': 'Sweet eyes',
  '困到融化': 'Melting sleepy', '猫猫亮眼': 'Kitten sparkles', '半眯审视': 'Side-eye', '圆圆亮眼': 'Bright eyes',
  '眼泪汪汪': 'Big tears', '懒懒半睁': 'Lazy eyes', '瀑布眼泪': 'Waterfall tears', '咧嘴笑眼': 'Grinning eyes', '趴着睡觉': 'Napping eyes',
  '小狗嘴': 'Puppy mouth', '小猫嘴': 'Kitten mouth', '笑一笑': 'Little smile', '软软嘴': 'Soft mouth',
  '嘟嘟嘴': 'Pout', '小小吻': 'Tiny kiss', '呜呜': 'Wah mouth', '小鼻尖': 'Tiny nose',
  '圆圆嘴': 'Round mouth', '轻轻笑': 'Gentle smile', '小小点': 'Tiny dot nose', '吐舌头': 'Tongue out',
  '小海鸥嘴': 'Wavy mouth', '委屈扁嘴': 'Sad pout', '亲亲小嘴': 'Kissy mouth', '乖乖抿嘴': 'Sweet mouth',
  '张大嘴': 'Wide open mouth', '小小圆嘴': 'Tiny O', '猫猫笑': 'Kitten smile', '平平嘴巴': 'Flat mouth',
  '微微嘟嘴': 'Soft pout', '惊讶小狗': 'Surprised mouth', '软软鼻子': 'Soft nose', '小小微笑': 'Tiny smile',
  '小小猫鼻': 'Kitten nose', '委屈小尖嘴': 'Pointy pout', '困困小嘴': 'Sleepy mouth',
  '调皮小舌头': 'Cheeky tongue', '趴睡小鼻子': 'Napping nose',
  '素颜小狗': 'No extras', '红扑扑': 'Rosy blush', '送你小心心': 'A heart for you', '伸出小爪': 'Little paw',
  '星星陪伴': 'Star friends', '困困 Zzz': 'Sleepy Zzz', '戴小蝴蝶结': 'Little bow', '闪亮小狗': 'Sparkles',
  '害羞斜线': 'Shy blush', '小脸红红': 'Soft blush', '举起爪爪': 'Paws up', '捧着心心': 'Holding a heart',
  '一朵小花': 'Little flower', '星星点点': 'Starry dots', '小小呼噜泡': 'Sleep bubble',
  '不戴角': 'No horns', '小恶魔角': 'Devil horns', '尖尖恶魔角': 'Pointy horns', '弯弯小角': 'Curved horns', '双尖小角': 'Twin horns',
  '不加尾巴': 'No tail', '恶魔箭尾': 'Arrow tail', '爱心恶魔尾': 'Devil heart tail', '空心爱心尾': 'Outline heart tail',
  '卷卷尾巴': 'Curly tail', '翘翘小尾巴': 'Perky tail', '长长小尾巴': 'Long tail', '小卷尾': 'Tiny curl',
  '不戴翅膀': 'No wings', '扑扇天使翼': 'Fluttering wings', '小天使翅膀': 'Angel wings',
  '圆圆天使翼': 'Round wings', '展开小翅膀': 'Spread wings', '星星天使翼': 'Starry wings',
  "字字兽": "Zizishou",
  "字字兽 · 颜文字团子工厂": "Zizishou · Kaomoji Creatures",
  "颜文字团子工厂": "Kaomoji Creature Studio",
  "捏一只属于你的字字兽。选小狗、小猫、兔兔或更多小动物，自由拼装颜文字。": "Make your own little creature. Choose a puppy, kitty, bunny and more. Mix and copy kaomoji.",
  "团子工坊": "Creature Studio",
  "什么字字兽？": "will you make today?",
  "刚出炉的软乎乎团子": "Freshly made fluffy creature",
  "✿ 复制团子": "✿ Copy creature",
  "复制团子": "Copy creature",
  "已复制": "Copied",
  "捏捏你的字字兽": "Make your creature",
  "选择小动物": "Choose an animal",
  "换一只团子，保留表情与配件": "Switch animals, keep the face and accessories",
  "字字兽集合啦": "The creature parade",
  "字字兽分类": "Creature categories",
  "再来一窝团子 ⤨": "Another batch ⤨",
  "收藏的字字兽 ♡": "Saved creatures ♡",
  "这里等着小团子入住": "A cozy home for your creatures",
  "点一下 ♡，就能把喜欢的团子留在这里。": "Tap ♡ to save a creature.",
  "去捏一只字字兽": "Make a creature",
  "字字兽负责可爱，你负责开心。": "The creatures bring the cute. You bring the smiles.",
  "长按，把团子带走": "Press and hold to take your creature",
  "待复制的团子颜文字": "Creature kaomoji to copy",
  "团子小窝已经住满 500 只啦": "Your home is full: 500 creatures!",
  "♡ 团子住进收藏夹啦": "♡ A creature joined your favorites!",
  "复制好啦！把团子带去聊天吧 ♡": "Copied! Take your creature to chat ♡",
  "空脸团子 · 等待你选零件": "Blank face · Choose some parts",
  "空空的小脸，重新捏一只吧": "Blank face, ready for your ideas",
  "小天使正在扑扇翅膀": "An angel is fluttering its wings",
  "团子困困，陪你慢慢休息": "A sleepy little creature",
  "这一只，是你的独家字字兽": "Your own one-of-a-kind creature",
  "全部团子": "All creatures",
  "噗叽！一只字字兽诞生啦": "Pop! A new creature is here!",
  "新的一窝团子来啦": "A new batch is here!",
  "小狗": "Puppy",
  "小猫": "Kitty",
  "兔兔": "Bunny",
  "熊熊": "Bear",
  "狐狸": "Fox",
  "仓鼠": "Hamster",
  "小狗团子": "Puppy creature",
  "小猫团子": "Kitty creature",
  "兔兔团子": "Bunny creature",
  "熊熊团子": "Bear creature",
  "狐狸团子": "Fox creature",
  "仓鼠团子": "Hamster creature",
  "兔兔长耳": "Bunny ears",
  "兔兔软耳": "Soft bunny ears",
  "熊熊圆耳": "Bear ears",
  "小熊抱抱": "Bear hug",
  "狐狸尖耳": "Fox ears",
  "狐狸蓬蓬": "Fluffy fox ears",
  "仓鼠团团": "Round hamster",
  "仓鼠鼓腮": "Puffy cheeks",
  "捏一只小狗": "Make a puppy",
  "日常小狗": "Everyday puppy",
  "开心小狗": "Happy puppy",
  "撒娇小狗": "Sweet puppy",
  "困困小狗": "Sleepy puppy",
  "委屈小狗": "Teary puppy",
  "天使小狗": "Angel puppy",
  "恶魔小狗": "Devil puppy",
  "捏一只小猫": "Make a kitty",
  "日常小猫": "Everyday kitty",
  "开心小猫": "Happy kitty",
  "撒娇小猫": "Sweet kitty",
  "困困小猫": "Sleepy kitty",
  "委屈小猫": "Teary kitty",
  "天使小猫": "Angel kitty",
  "恶魔小猫": "Devil kitty",
  "捏一只兔兔": "Make a bunny",
  "日常兔兔": "Everyday bunny",
  "开心兔兔": "Happy bunny",
  "撒娇兔兔": "Sweet bunny",
  "困困兔兔": "Sleepy bunny",
  "委屈兔兔": "Teary bunny",
  "天使兔兔": "Angel bunny",
  "恶魔兔兔": "Devil bunny",
  "捏一只熊熊": "Make a bear",
  "日常熊熊": "Everyday bear",
  "开心熊熊": "Happy bear",
  "撒娇熊熊": "Sweet bear",
  "困困熊熊": "Sleepy bear",
  "委屈熊熊": "Teary bear",
  "天使熊熊": "Angel bear",
  "恶魔熊熊": "Devil bear",
  "捏一只狐狸": "Make a fox",
  "日常狐狸": "Everyday fox",
  "开心狐狸": "Happy fox",
  "撒娇狐狸": "Sweet fox",
  "困困狐狸": "Sleepy fox",
  "委屈狐狸": "Teary fox",
  "天使狐狸": "Angel fox",
  "恶魔狐狸": "Devil fox",
  "捏一只仓鼠": "Make a hamster",
  "日常仓鼠": "Everyday hamster",
  "开心仓鼠": "Happy hamster",
  "撒娇仓鼠": "Sweet hamster",
  "困困仓鼠": "Sleepy hamster",
  "委屈仓鼠": "Teary hamster",
  "天使仓鼠": "Angel hamster",
  "恶魔仓鼠": "Devil hamster",
  "正在准备团子工坊。若长时间未就绪，请退出后重新打开。": "Getting the studio ready. Reopen the tool if it takes too long.",
  "当前无法读取收藏，请在新版小红书中重开小工具": "Favorites are unavailable. Reopen the tool in an updated Xiaohongshu app.",
  "收藏未确认保存，可以稍后再试": "The save could not be confirmed. Try again later.",
  "本次语言已切换，偏好暂未保存": "Language changed for this session. The preference could not be saved.",
  "颜文字已选中。长按文字，在系统选字菜单中点「复制」。": "The kaomoji is selected. Press and hold the text, then choose Copy in the system selection menu.",
  "全选文字": "Select all",
  "表情卡": "Creature card",
  "字字兽分享卡片": "Creature share card",
  "保存到相册": "Save to Photos",
  "可以预览卡片。保存或分享请在支持的小红书客户端使用。": "Preview the card here. Open it in a supported Xiaohongshu app to save or share.",
  "在小红书搜「字字兽」，捏一只你的团子": "Find 字字兽 on Xiaohongshu and make your own creature.",
  "已保存到相册": "Saved to Photos",
  "保存到相册未确认，请检查权限后再试": "Save not confirmed. Check Photos permission and try again.",
  "请在小红书全屏打开后分享": "Open the tool fullscreen in Xiaohongshu to share.",
  "暂时无法分享，可以稍后再试": "Sharing is unavailable. Try again later.",
};
function hasHanText(text){return /[\u3400-\u9fff\uf900-\ufaff]/u.test(text)}
function translate(value, language = 'zh') {
  const source = String(value);
  if (language !== 'en' || !hasHanText(source)) return source;
  const core = source.trim(), leading = source.slice(0, source.indexOf(core)), trailing = source.slice(source.indexOf(core) + core.length);
  let result = EN[core];
  if (result === undefined) {
    let match;
    if ((match = core.match(/^(\d+) \/ (\d+) 个零件$/))) result = `${match[1]} / ${match[2]} parts`;
    else if ((match = core.match(/^我的收藏，(\d+)只团子$/))) result = `Favorites, ${match[1]} creatures`;
    else if ((match = core.match(/^我的收藏，(\d+)只小狗$/))) result = `Favorites, ${match[1]} puppies`;
    else if ((match = core.match(/^(取消收藏|收藏) ([\s\S]+)$/))) result = `${match[1] === '收藏' ? 'Save' : 'Unsave'} ${match[2]}`;
    else if ((match = core.match(/^(选择眼睛|选择嘴巴|换一对小耳朵|腮红与小装饰)：([\s\S]+)$/))) result = `${translate(match[1], 'en')}: ${translate(match[2], 'en')}`;
    else if ((match = core.match(/^搜索([\s\S]+)$/))) result = `Search: ${translate(match[1], 'en')}`;
    else if ((match = core.match(/^(左耳|右耳|左眼|右眼|嘴巴|前面的小装饰|后面的小装饰)自定义$/))) result = `Custom: ${translate(match[1], 'en')}`;
    else if (core.includes(' / ')) result = core.split(' / ').map(s => translate(s, 'en')).join(' / ');
    else if (core.includes(' · ')) result = core.split(' · ').map(s => translate(s, 'en')).join(' · ');
  }
  return leading + (result === undefined ? core : result) + trailing;
}
function readLanguage(storage) {
  try { return storage.getItem(LANGUAGE_KEY) === 'en' ? 'en' : 'zh'; } catch (error) { return 'zh'; }
}
function writeLanguage(storage, language) {
  if (!['zh', 'en'].includes(language)) return false;
  try { storage.setItem(LANGUAGE_KEY, language); return true; } catch (error) { return false; }
}

return {LANGUAGE_KEY, EN, hasHanText, translate, readLanguage, writeLanguage};
}());

const picker = (function(){
const {translate} = i18n;
const {PARTS, ACCESSORIES, NEW_PARTS, DEFAULT, cloneState} = model;

const RECENT_KEY = 'puppy-factory:recent-parts';
const OPTIONS = Object.assign({},PARTS,ACCESSORIES);
const EYE_MOODS = {
  '开心': [3, 2, 14, 20, 26, 31],
  '困': [4, 5, 24, 28, 33, 36],
  '哭': [7, 16, 17, 18, 32, 34],
  '坏笑': [30, 11, 15, 19, 9, 25],
  '害羞': [13, 27, 11, 0, 21, 8],
};
const COMMON = {
  eyes: [0, 1, 3, 4, 12, 30, 31, 32],
  mouth: [0, 2, 3, 4, 6, 9, 15, 26],
  ears: [1, 0, 2, 3, 7, 8, 12, 13],
  decor: [1, 0, 2, 3, 6, 9, 11, 14],
};
function validIndex(key, value) {
  const options=OPTIONS[key]||[];
  return Number.isInteger(value) && value >= 0 && value < options.length;
}
function cleanRecent(data) {
  const result = {};
  if (!data || typeof data !== 'object' || Array.isArray(data)) return result;
  for (const key of Object.keys(OPTIONS)) {
    if (Array.isArray(data[key])) result[key] = [...new Set(data[key].filter(i => validIndex(key, i)))].slice(0, 8);
  }
  return result;
}
function readRecent(storage) {
  try { return cleanRecent(JSON.parse(storage.getItem(RECENT_KEY) || '{}')); }
  catch (error) { return {}; }
}
function usePart(recent, key, index) {
  const next = cleanRecent(recent);
  if (validIndex(key, index)) next[key] = [index, ...(next[key] || []).filter(i => i !== index)].slice(0, 8);
  return next;
}
function writeRecent(storage, recent) {
  try { storage.setItem(RECENT_KEY, JSON.stringify(cleanRecent(recent))); return true; }
  catch (error) { return false; }
}
function partTray(key, {recent = {}, expanded = false, query = '', mood = '常用'} = {}) {
  const items = OPTIONS[key] || [];
  const order = [...new Set([
    ...(cleanRecent(recent)[key] || []), ...(COMMON[key] || []), ...(NEW_PARTS[key] || []),
    ...items.map((_, i) => i),
  ])].filter(i => validIndex(key, i));
  const q = query.trim().toLowerCase();
  const candidates = order.filter(i => {
    if (items[i].hidden) return false;
    if (q) return (items[i].name + ' ' + translate(items[i].name,'en') + ' ' + (Array.isArray(items[i].v) ? items[i].v.join(' ') : items[i].v)).toLowerCase().includes(q);
    return key !== 'eyes' || mood === '常用' || (EYE_MOODS[mood] || []).includes(i);
  });
  return {visible: expanded ? candidates : candidates.slice(0, 8), total: candidates.length, hasMore: candidates.length > 8};
}
function clearFace(state) {
  const empty = cloneState(DEFAULT);
  empty.ears = state.ears;
  empty.decor = 0;
  empty.custom = {eyeLeft: '', eyeRight: '', mouth: ''};
  return empty;
}
function compactDock({mobile, workbenchTop, wasCompact = false}) {
  // Hysteresis avoids toggling near the sticky boundary as mobile browser chrome moves.
  return mobile && workbenchTop < (wasCompact ? 4 : -12);
}
function anchorTop(sectionTop, scrollY, dockHeight, mobile) {
  return Math.max(0, sectionTop + scrollY - (mobile ? dockHeight + 12 : 24));
}

return {RECENT_KEY, EYE_MOODS, cleanRecent, readRecent, usePart, writeRecent, partTray, clearFace, compactDock, anchorTop};
}());

const sharing = (function(){
const W = 1080, H = 1440;
const INK = '#614d46', MUTED = '#a78a7c', PINK = '#d794a1', CREAM = '#fffaf5';
const SANS = "'PingFang SC','Noto Sans SC','Microsoft YaHei',system-ui,sans-serif";
const FACE = "PuppyUnicode,'Noto Sans','Arial Unicode MS','DejaVu Sans',sans-serif";

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

async function drawShareCard(canvas, face, caption, labels) {
  const scale = 0.75;
  canvas.width = W * scale; canvas.height = H * scale;
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas drawing is unavailable');
  if (document.fonts && typeof document.fonts.load === 'function') {
    try {
      await Promise.race([
        document.fonts.load('120px PuppyUnicode', face),
        new Promise(resolve => setTimeout(resolve, 350))
      ]);
    } catch (error) {}
  }
  ctx.scale(scale, scale);

  // 粉色波点纸
  ctx.fillStyle = '#fbe9ec'; ctx.fillRect(0, 0, W, H);
  ctx.fillStyle = 'rgba(215,148,161,.38)';
  for (let y = 18; y < H; y += 36) for (let x = (y / 36) % 2 ? 36 : 18; x < W; x += 36) { ctx.beginPath(); ctx.arc(x, y, 4, 0, Math.PI * 2); ctx.fill(); }

  // 卡片
  ctx.save(); ctx.shadowColor = 'rgba(180,94,120,.22)'; ctx.shadowBlur = 40; ctx.shadowOffsetY = 14;
  ctx.fillStyle = CREAM; roundRect(ctx, 80, 120, W - 160, 1160, 48); ctx.fill(); ctx.restore();
  ctx.lineWidth = 5; ctx.strokeStyle = PINK; roundRect(ctx, 80, 120, W - 160, 1160, 48); ctx.stroke();

  ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
  ctx.fillStyle = '#ad8878'; ctx.font = `600 26px ${SANS}`;
  ctx.fillText('T H E   L I T T L E   K A O M O J I   S T U D I O', W / 2, 220);

  // 团子本体：太长就自动缩小
  ctx.fillStyle = '#f8ece6'; roundRect(ctx, 140, 290, W - 280, 440, 36); ctx.fill();
  let size = 132; ctx.font = `${size}px ${FACE}`;
  while (ctx.measureText(face).width > W - 360 && size > 40) { size -= 4; ctx.font = `${size}px ${FACE}`; }
  ctx.fillStyle = INK; ctx.fillText(face, W / 2, 510, W - 360);

  ctx.fillStyle = MUTED; ctx.font = `38px ${SANS}`; ctx.fillText(caption, W / 2, 800);

  // 分隔虚线
  ctx.strokeStyle = '#ead8d0'; ctx.lineWidth = 3; ctx.setLineDash([12, 10]);
  ctx.beginPath(); ctx.moveTo(140, 880); ctx.lineTo(W - 140, 880); ctx.stroke(); ctx.setLineDash([]);

  ctx.fillStyle = INK;
  ctx.font = `700 50px ${SANS}`;
  ctx.fillText(labels.brand, W / 2, 995, W - 300);
  ctx.fillStyle = MUTED;
  ctx.font = `34px ${SANS}`;
  ctx.fillText(labels.tagline, W / 2, 1095, W - 300);

  ctx.textAlign = 'center'; ctx.fillStyle = '#b48a90'; ctx.font = `30px ${FACE}`;
  ctx.fillText('૮₍ ˶• ﻌ •˶ ₎ა  ♡', W / 2, 1360);
  return canvas;
}

return {drawShareCard};
}());

const container = (function(){
const STORAGE_VERSION=9460;

function clientVersion(options){
  const env=options&&options.miniToolEnv;
  const value=env&&env.buildVersion;
  if((typeof value!=='number'&&typeof value!=='string')||!/^[1-9]\d{6,}$/.test(String(value)))return null;
  const build=Number(value);
  return Number.isSafeInteger(build)?Math.floor(build/1000):null;
}

function invoke(api,method,options,timeout){
  return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>reject(new Error(method+' timed out')),timeout);
    Promise.resolve().then(()=>api[method](options)).then(
      result=>{clearTimeout(timer);resolve(result)},
      error=>{clearTimeout(timer);reject(error)}
    );
  });
}

function createMiniTool(xhs){
  const api=xhs&&xhs.miniTool;
  const initialOptions=xhs&&xhs.launchOptions;
  const launch=clientVersion(initialOptions)===null&&api&&typeof api.getLaunchOptions==='function'
    ?invoke(api,'getLaunchOptions',{},2000).catch(()=>initialOptions)
    :Promise.resolve(initialOptions);

  async function supports(method,minimum){
    const version=clientVersion(await launch);
    return version!==null&&version>=minimum&&!!api&&typeof api[method]==='function';
  }

  return {
    launch,
    supports,
    async call(method,minimum,options={},timeout=3500){
      if(!await supports(method,minimum))throw new Error(method+' is unavailable');
      const result=await invoke(api,method,options,timeout);
      if(!result||result.errMsg!==method+':ok')throw result||new Error(method+' did not confirm success');
      return result;
    }
  };
}

function createPreferences(tool){
  const loaded=new Set();
  const writes=new Map();
  return {
    async read(key,validate){
      loaded.delete(key);
      try{
        const result=await tool.call('getStorage',STORAGE_VERSION,{key});
        if(result.data===null){
          loaded.add(key);
          return {ok:true,value:null};
        }
        if(typeof result.data!=='string')return {ok:false,value:null};
        const value=JSON.parse(result.data);
        if(!validate(value))return {ok:false,value:null};
        loaded.add(key);
        return {ok:true,value};
      }catch(error){
        return {ok:false,value:null};
      }
    },
    write(key,value){
      const data=JSON.stringify(value);
      const previous=writes.get(key)||Promise.resolve();
      const write=previous.then(async()=>{
        if(!loaded.has(key))return false;
        try{
          await tool.call('setStorage',STORAGE_VERSION,{key,data});
          return true;
        }catch(error){
          return false;
        }
      });
      writes.set(key,write);
      return write;
    }
  };
}

function topInset(info){
  if(!info)return 0;
  const safe=info.safeArea&&info.safeArea.top;
  const menus=info.menuButtons||{};
  const visible=rect=>rect&&rect.width>0&&rect.height>0&&Number.isFinite(rect.bottom);
  const buttons=visible(menus.capsule)?[menus.capsule]:[menus.back,menus.me,menus.share].filter(visible);
  const floor=Number.isFinite(safe)?Math.max(0,safe):0;
  const bottom=buttons.reduce((max,rect)=>Math.max(max,rect.bottom),floor);
  return bottom>0?bottom+8:0;
}

return {clientVersion, createMiniTool, createPreferences, topInset};
}());

(function(){
const {earSegments,PARTS,ACCESSORIES,FRESH_LOOKS,ANIMALS,ANIMAL_LOOKS,animalForEar,randomAnimalState,DEFAULT,FAVORITES_KEY,cloneState,values,composeParts,compose,faceSpacing,hasOwn,validState} = model;
const {drawShareCard} = sharing;
const {RECENT_KEY,EYE_MOODS,cleanRecent,usePart,partTray,clearFace,compactDock,anchorTop} = picker;
const {LANGUAGE_KEY,hasHanText,translate} = i18n;
const {createMiniTool,createPreferences,topInset} = container;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const miniTool=createMiniTool(window.xhs);
const preferences=createPreferences(miniTool);
let state=cloneState(DEFAULT),filter='全部团子',counter=1,toastTimer,gallery=[],history=[];
let language='zh',languageChanged=false;
let favorites=[],favoritesReady,loadingFavorites=true,savingFavorite=false;
let recent={},recentReady,recentSaveTimer;
const textBindings=new Map(),attributeBindings=new Map();
function setText(node,value){const source=String(value);const literal=node.classList.contains('kaomoji')||node.id==='puppy';node.textContent=literal?source:translate(source,language);if(!literal&&node.firstChild)textBindings.set(node.firstChild,source)}
function localizedAttr(node,name,value){const source=String(value);node.setAttribute(name,translate(source,language));if(!attributeBindings.has(node))attributeBindings.set(node,new Map());attributeBindings.get(node).set(name,source)}
function bindStaticText(){
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);let node;
 while((node=walker.nextNode())){if(hasHanText(node.data)&&!node.parentElement.closest('.kaomoji,script,style,[data-language]'))textBindings.set(node,node.data)}
 document.querySelectorAll('[aria-label],[placeholder],[title]').forEach(node=>{for(const name of ['aria-label','placeholder','title'])if(node.hasAttribute(name))localizedAttr(node,name,node.getAttribute(name))});
}
function applyLanguage(){
 for(const [node,source]of textBindings){if(node.isConnected)node.data=translate(source,language);else textBindings.delete(node)}
 for(const [node,attrs]of attributeBindings){if(!node.isConnected){attributeBindings.delete(node);continue}for(const [name,source]of attrs)node.setAttribute(name,translate(source,language))}
 document.documentElement.lang=language==='en'?'en':'zh-CN';document.documentElement.dataset.language=language;
 document.title=translate('字字兽 · 颜文字团子工厂',language);
 document.querySelector('meta[name="description"]').content=translate('捏一只属于你的字字兽。选小狗、小猫、兔兔或更多小动物，自由拼装颜文字。',language);
 $$('[data-language]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.language===language)));queueDock();
}
const trays=new Map();
const categories=['全部团子',...ANIMALS.map(x=>x.name),'新到表情','小恶魔','小天使','开心','撒娇','困困','委屈'];
const customKeys={ears:['left','right','leftOuter','leftFrame','leftInner','rightInner','rightFrame','rightOuter'],eyes:['eyeLeft','eyeRight'],mouth:['mouth'],decor:['prefix','suffix','blushLeft','blushRight']};
const accessorySlots={horns:['hornLeft','hornRight'],wings:['wingLeft','wingRight'],tail:['tail'],hands:['handLeft','handRight']};
const names={left:'左耳',right:'右耳',eyeLeft:'左眼',eyeRight:'右眼',mouth:'嘴巴',prefix:'前面的小装饰',suffix:'后面的小装饰',leftOuter:'左外耳',handLeft:'左手',handRight:'右手',leftFrame:'左脸边',leftInner:'左内侧',rightInner:'右内侧',rightFrame:'右脸边',rightOuter:'右外耳',blushLeft:'左腮红',blushRight:'右腮红',hornLeft:'左角',hornRight:'右角',wingLeft:'左翅膀',wingRight:'右翅膀',tail:'尾巴'};
const labels={eyes:'选择眼睛',mouth:'选择嘴巴',ears:'换一对小耳朵',decor:'腮红与小装饰'};
const looks=[
 {name:'委屈小狗',state:Object.assign(cloneState(DEFAULT),{eyes:12,mouth:6})},
 {name:'小恶魔',state:Object.assign(cloneState(DEFAULT),{accessories:{horns:1,tail:0,wings:0}})},
 {name:'摇尾小恶魔',state:Object.assign(cloneState(DEFAULT),{accessories:{horns:1,tail:1,wings:0}})},
 {name:'扑扇小天使',state:Object.assign(cloneState(DEFAULT),{ears:8,eyes:13,mouth:9,decor:0,accessories:{horns:0,tail:0,wings:1}})},
 {name:'天使小狗',state:Object.assign(cloneState(DEFAULT),{eyes:3,accessories:{horns:0,tail:0,wings:2}})},
 {name:'困困抱抱',state:Object.assign(cloneState(DEFAULT),{eyes:4,mouth:3,decor:0,accessories:{horns:0,tail:0,wings:0,hands:7}})}
];
function el(tag,cls,text){const n=document.createElement(tag);if(cls)n.className=cls;/* 拾 11-23：浏览器翻译会把 ó ò 翻成「哦」，颜文字一律不让翻 */if(cls&&/\bkaomoji\b|card-puppy/.test(cls))n.translate=false;if(text!==undefined)setText(n,text);return n}
function button(cls,text,fn){const b=el('button',cls,text);b.type='button';b.addEventListener('click',fn);return b}
function replaceContents(node,...children){
 node.textContent='';
 node.append(...children);
}
function toast(message){setText($('#toast'),message);$('#toast').classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),2400)}
function checkpoint(){history.push(cloneState(state));if(history.length>40)history.shift()}
function rememberPart(key,index){
 recent=usePart(recent,key,index);
 clearTimeout(recentSaveTimer);
 recentSaveTimer=setTimeout(async()=>{
  if(await recentReady)preferences.write(RECENT_KEY,recent);
 },180);
}
function change(fn,{remember=true}={}){const previous=cloneState(state);checkpoint();fn();if(remember){for(const k of Object.keys(PARTS))if(previous[k]!==state[k])rememberPart(k,state[k]);for(const k of Object.keys(ACCESSORIES))if(previous.accessories[k]!==state.accessories[k])rememberPart(k,state.accessories[k])}render();syncCustom()}
const hasSaved=s=>favorites.some(x=>compose(x)===compose(s));
async function loadFavorites(){
 loadingFavorites=true;
 const record=await preferences.read(FAVORITES_KEY,list=>Array.isArray(list)&&list.every(validState));
 loadingFavorites=false;
 if(record.ok)favorites=(record.value||[]).slice(0,500).map(cloneState);
 $('#favorites-storage-status').hidden=record.ok;
 $('#favorite-count').hidden=!record.ok;
 renderSaved();
 if(record.ok)renderGallery();
 renderFavorites();
 return record.ok;
}
async function loadRecent(){
 const record=await preferences.read(RECENT_KEY,value=>value&&typeof value==='object'&&!Array.isArray(value));
 if(!record.ok)return false;
 const restored=cleanRecent(record.value);
 for(const [key,indices] of Object.entries(recent)){
  restored[key]=[...new Set(indices.concat(restored[key]||[]))].slice(0,8);
 }
 recent=restored;
 updateTrays();
 return true;
}
async function save(s){
 if(savingFavorite)return;
 const selected=cloneState(s);
 savingFavorite=true;
 try{
  if(!await favoritesReady){
   toast('当前无法读取收藏，请在新版小红书中重开小工具');
   return;
  }
  const text=compose(selected);
  const added=!hasSaved(selected);
  const next=added?[selected,...favorites]:favorites.filter(item=>compose(item)!==text);
  if(next.length>500){
   toast('团子小窝已经住满 500 只啦');
   return;
  }
  if(!await preferences.write(FAVORITES_KEY,next)){
   toast('收藏未确认保存，可以稍后再试');
   favoritesReady=loadFavorites();
   return;
  }
  favorites=next;
  renderSaved();
  renderGallery();
  renderFavorites();
  toast(added?'♡ 团子住进收藏夹啦':'已从收藏中移出');
 }finally{
  savingFavorite=false;
 }
}
let selectedOutput;
function selectText(){
 const input=$('#copy-text');
 input.focus();
 input.setSelectionRange(0,input.value.length);
}
function takeCreature(s){
 selectedOutput=cloneState(s);
 $('#copy-text').value=compose(selectedOutput);
 $('#manual-copy').showModal();
 selectText();
}
function renderSaved(){$('#favorite-count').textContent=favorites.length;$('#save').setAttribute('aria-pressed',String(hasSaved(state)));setText($('#save'),hasSaved(state)?'♥ 已收藏':'♡ 收藏');$$('.nav-item').forEach(b=>{if(b.dataset.view==='favorites')localizedAttr(b,'aria-label',`我的收藏，${favorites.length}只团子`)})}
let renderedFaceParts,highlightTimer;
// 拾 11-23：随机、一键穿搭、新到的小表情、集合里的「捏捏」、清空，都是整只换掉，不需要标出哪里变了，所以跳过强调。
let quietFace=false;
function renderFace(){
 const quiet=quietFace;quietFace=false;
 const parts=composeParts(state);
 if(renderedFaceParts&&renderedFaceParts.size===parts.length&&parts.every(([key,text])=>renderedFaceParts.get(key)===text))return;

 const preview=document.createDocumentFragment();
 for(const [key,text] of parts){
  // Ignore padding-only differences, such as the spaces trimmed when putting on horns.
  if(!quiet&&renderedFaceParts&&(renderedFaceParts.get(key)||'').trim()!==text.trim()){
   const mark=el('span','preview-change');
   mark.dataset.part=key;
   mark.textContent=text;
   preview.append(mark);
  }else preview.append(text);
 }
 preview.normalize();
 const face=$('#puppy-text');
 replaceContents(face,preview.cloneNode(true));
 replaceContents($('#slot-preview'),preview);
 $('#puppy').classList.toggle('long-puppy',Array.from(face.textContent).length>27);
 renderedFaceParts=new Map(parts);

 clearTimeout(highlightTimer);
 if(face.querySelector('.preview-change')){
  highlightTimer=setTimeout(()=>$$('.preview-change').forEach(mark=>mark.classList.remove('preview-change')),1600);
 }
}
function render(){
 const currentSpace=faceSpacing(state);
 $$('[data-spacing]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.spacing===currentSpace)));
 renderFace();
 const recipe=['ears','eyes','mouth','decor'].map(k=>PARTS[k][state[k]].name);
 Object.entries(state.accessories||{}).forEach(([k,v])=>{if(v)recipe.push(ACCESSORIES[k][v].name)});
 setText($('#recipe'),state.custom.eyeLeft===''&&state.custom.eyeRight===''&&state.custom.mouth===''?'空脸团子 · 等待你选零件':recipe.join(' / ')+(Object.keys(state.custom).length?' · 自定义':''));
 setText($('#puppy-caption'),state.custom.eyeLeft===''&&state.custom.eyeRight===''&&state.custom.mouth===''?'空空的小脸，重新捏一只吧':state.accessories.wings?'小天使正在扑扇翅膀':state.accessories.horns?'今天也是可爱的小恶魔':PARTS.eyes[state.eyes].mood==='困困'?'团子困困，陪你慢慢休息':'这一只，是你的独家字字兽');
 $('#puppy-number').textContent=String(counter).padStart(3,'0');$('#undo').disabled=!history.length;
 $$('[data-animal]').forEach(b=>b.setAttribute('aria-pressed',String(animalForEar(state.ears)===b.dataset.animal)));
 updateTrays();
 $$('[data-choice]').forEach(b=>{const k=b.dataset.choice;b.setAttribute('aria-pressed',String(state[k]===Number(b.dataset.index)&&!customKeys[k].some(x=>hasOwn(state.custom,x))))});
 $$('[data-accessory]').forEach(b=>b.setAttribute('aria-pressed',String((state.accessories[b.dataset.accessory]||0)===Number(b.dataset.index))));
 renderSaved();
}
function sample(k,x){if(k==='ears')return x.v[0]+'◦'+x.v[1];if(k==='eyes')return x.v[0]+' '+x.v[1];if(k==='mouth')return x.v;return x.v.join('')||'—'}
function buildFamilies(){ANIMALS.forEach(animal=>{const look=ANIMAL_LOOKS.find(x=>x.id===animal.id);const b=button('family-option','',()=>change(()=>{state.ears=animal.earIndex;customKeys.ears.forEach(k=>delete state.custom[k]);rememberPart('ears',state.ears);/* 狐狸自带爪爪：没戴手时自动配上；换走时只撤掉自动配的那副 */const a=state.accessories;if(autoHands&&a.hands===autoHands&&animal.hands!==autoHands){a.hands=0;autoHands=0}if(animal.hands&&!a.hands){a.hands=animal.hands;autoHands=animal.hands;accessorySlots.hands.forEach(s=>delete state.custom[s])}}));b.dataset.animal=animal.id;localizedAttr(b,'aria-label','捏一只'+animal.name);b.append(el('span','kaomoji',compose(look.state)),el('small','',animal.name));$('#families').append(b)})}
function buildCustom(k){const details=el('details','custom-editor');details.append(el('summary','','自己输入'+(k==='decor'?'前后装饰':labels[k].replace('选择','').replace('换一对小',''))));const grid=el('div','custom-fields');(k==='ears'?['left','right']:customKeys[k]).forEach(key=>{const label=el('label','',names[key]);const input=el('input');input.type='text';input.dir='ltr';input.dataset.custom=key;localizedAttr(input,'aria-label',names[key]+'自定义');input.autocomplete='off';input.spellcheck=false;input.addEventListener('focus',checkpoint);input.addEventListener('input',()=>{state.custom[key]=Array.from(input.value.replace(/[\u0000-\u001f\u007f\u202a-\u202e\u2066-\u2069]/gu,'')).slice(0,16).join('');render()});label.append(input);grid.append(label)});details.append(grid);return details}
function syncCustom(){const v=values(state);$$('[data-custom]').forEach(input=>input.value=v[input.dataset.custom])}
function updateTray(tray){
 const result=partTray(tray.key,{recent,expanded:tray.rail||tray.expanded,query:tray.query,mood:tray.mood});
 const visible=new Set(result.visible),order=[...((tray.key==='decor'||hasOwn(ACCESSORIES,tray.key))&&visible.has(0)?[0]:[]),...result.visible,...tray.buttons.keys()].filter((x,i,a)=>a.indexOf(x)===i);
 const focused=document.activeElement;
 if(tray.lastOrder!==order.join(',')&&(!tray.rail||!tray.lastOrder||tray.allowReorder)){tray.grid.append(...order.map(i=>tray.buttons.get(i)));tray.lastOrder=order.join(',')}
 tray.buttons.forEach((b,i)=>{b.hidden=!visible.has(i);b.classList.toggle('recent-choice',(recent[tray.key]||[]).includes(i));localizedAttr(b,'title',((recent[tray.key]||[]).includes(i)?'最近使用 · ':'')+tray.items[i].name)});
 setText(tray.count,`${result.visible.length} / ${result.total} 个零件`);
 tray.empty.hidden=result.total>0;tray.toggle.hidden=tray.rail||!result.hasMore;setText(tray.toggle,tray.expanded?'收起，只看常用 ▴':'展开全部 ▾');tray.toggle.setAttribute('aria-expanded',String(tray.expanded));
 if(tray.moodHost)[...tray.moodHost.children].forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.mood===tray.mood)));
 if(focused&&tray.grid.contains(focused)&&!focused.hidden&&document.activeElement!==focused)focused.focus({preventScroll:true});fitTray(tray);
}
function updateTrays(){trays.forEach(updateTray)}
function buildPart(k,open=true){
 const section=el(open?'section':'details','picker-section');section.id='picker-'+k;
 const heading=el(open?'div':'summary','picker-heading'),count=el('span');heading.append(el('h3','',labels[k]),count);section.append(heading);
 const grid=el('div','choices expanded-choices part-rail');grid.id='choices-'+k;
 const empty=el('p','part-empty','没有找到，试试换个名字，或展开下方自定义。');empty.hidden=true;
 const tray={key:k,grid,count,empty,expanded:false,rail:true,query:'',mood:'常用',buttons:new Map(),items:PARTS[k]};
 if(k==='eyes'){
  const moods=el('div','mood-tabs');localizedAttr(moods,'aria-label','眼睛心情');
  for(const mood of ['常用',...Object.keys(EYE_MOODS)]){const b=button('mood-chip',mood,()=>{tray.mood=mood;tray.expanded=false;tray.query='';tray.search.value='';updateTray(tray)});b.dataset.mood=mood;moods.append(b)}
  tray.moodHost=moods;section.append(moods);
 }
 if(k==='eyes'||k==='mouth'){
  const search=el('input','part-search');search.type='search';localizedAttr(search,'placeholder',k==='eyes'?'搜名字或符号：≖、困困、眼泪…':'搜名字或符号：小舌头、猫鼻…');localizedAttr(search,'aria-label','搜索'+labels[k]);
  search.addEventListener('input',()=>{tray.query=search.value;tray.expanded=false;updateTray(tray)});tray.search=search;section.append(search);
 }
 PARTS[k].forEach((x,i)=>{
  const b=button('choice'+(k==='decor'&&i===0?' none-choice':''),'',()=>{const cur=state[k];if(cur===i&&prevPick[k]===undefined)return;change(()=>{if(cur===i){state[k]=prevPick[k];delete prevPick[k]}else{prevPick[k]=cur;state[k]=i}customKeys[k].forEach(key=>delete state.custom[key]);rememberPart(k,state[k])})});
  b.dataset.choice=k;b.dataset.index=i;localizedAttr(b,'aria-label',labels[k]+'：'+x.name);b.append(el('span','kaomoji',sample(k,x)),el('small','',x.name));tray.buttons.set(i,b);
 });
 tray.toggle=button('expand-parts','展开全部 ▾',()=>{tray.expanded=!tray.expanded;updateTray(tray)});tray.toggle.setAttribute('aria-controls',grid.id);
 trays.set(k,tray);section.append(empty,grid,tray.toggle,buildCustom(k));return section;
}
function buildAccessories(rows=[['horns','小恶魔角'],['tail','小尾巴'],['wings','天使翅膀']],title='角、尾巴与翅膀',note='三种可以一起戴',id='picker-accessories'){
 const section=el('section','picker-section accessory-section');section.id=id;const h=el('div','picker-heading');h.append(el('h3','',title),el('span','',note));section.append(h);
 for(const [key,label]of rows){
  const row=el('fieldset','accessory-row'),legend=el('legend','',label),count=el('span','accessory-count');legend.append(count);row.append(legend);
  const grid=el('div','accessory-choices part-rail');grid.id='choices-'+key;const empty=el('p','part-empty');empty.hidden=true;
  const tray={key,grid,count,empty,expanded:false,rail:true,query:'',mood:'常用',buttons:new Map(),items:ACCESSORIES[key]};
  ACCESSORIES[key].forEach((x,i)=>{const b=button('choice accessory-choice'+(i===0?' none-choice':''),'',()=>{const cur=state.accessories[key]||0;let selected;if(cur===i){if(prevPick[key]===undefined&&i===0)return;selected=prevPick[key]==null?0:prevPick[key];delete prevPick[key]}else{prevPick[key]=cur;selected=i}if(key==='hands')autoHands=0;change(()=>{state.accessories[key]=selected;accessorySlots[key].forEach(slot=>delete state.custom[slot]);rememberPart(key,selected)})});b.dataset.accessory=key;b.dataset.index=i;localizedAttr(b,'aria-label',x.name);b.append(el('span','kaomoji',i===0?'—':Array.isArray(x.v)?x.v.join('\u200e ◦ \u200e'):x.v.trim()),el('small','',x.name));tray.buttons.set(i,b)});
  tray.toggle=button('expand-parts','展开全部 ▾',()=>{tray.expanded=!tray.expanded;updateTray(tray)});tray.toggle.setAttribute('aria-controls',grid.id);trays.set(key,tray);row.append(grid,tray.toggle);section.append(row);
 }
 return section;
}
function buildControls(){buildFamilies();FRESH_LOOKS.forEach(look=>{const b=button('preset fresh-preset','',()=>{quietFace=true;change(()=>{state=cloneState(look.state);counter++})});b.append(el('span','kaomoji',compose(look.state)),el('small','',look.name));$('#fresh-presets').append(b)});$$('[data-spacing]').forEach(b=>b.addEventListener('click',()=>change(()=>{state.spacing=b.dataset.spacing}))); [...ANIMAL_LOOKS,...looks].forEach(look=>{const b=button('preset','',()=>{quietFace=true;change(()=>{state=cloneState(look.state);counter++})});b.append(el('span','kaomoji',compose(look.state)),el('small','',look.name));$('#presets').append(b)});const earDecor=el('section','ear-decor-group');earDecor.id='picker-ears-and-decor';earDecor.append(buildPart('ears'),buildAccessories([['hands','']],'小手','举在外面，或者抱在怀里','picker-hands'),buildPart('decor'));const face=el('section','ear-decor-group face-group');face.id='picker-face';face.append(buildPart('eyes'),buildPart('mouth'));$('#all-parts').append(face,buildAccessories(),earDecor);showPart(activePart);}
// 2026-11-23 拾：像换装游戏一样——顶上的「眼睛 / 嘴巴 / 角 / 耳朵」是切换标签，下面一次只摆一格衣柜，每格两排左右滑。
// 2026-11-23 19:08 拾：眼睛、嘴巴合成一格「眼睛·嘴巴」；耳朵那格叫「耳朵·装饰·爪爪」。
// 2026-11-23 拾：选中的零件再点一下＝反悔这一下，回到点它之前的那一个（配件一开始是「不带」，所以通常就是取消）。
// 2026-11-23 拾：格子窄，长一点的零件（૮(ᐢ ◦ ᐢ)ა）右边被切掉。放不下就按比例缩小字号。
function fitTray(tray){if(!tray.rail)return;tray.grid.querySelectorAll('.choice:not([hidden]) .kaomoji').forEach(k=>{k.style.fontSize='';const w=k.clientWidth,sw=k.scrollWidth;if(w&&sw>w){const fs=parseFloat(getComputedStyle(k).fontSize);k.style.fontSize=Math.max(9,Math.floor(fs*w/sw*0.96))+'px'}})}
function fitAll(){trays.forEach(fitTray)}addEventListener('resize',()=>requestAnimationFrame(fitAll),{passive:true});if(document.fonts&&document.fonts.ready)document.fonts.ready.then(fitAll);
const prevPick={};let autoHands=0;
const PART_TABS=['face','accessories','ears-and-decor'];let activePart='face';
function showPart(id){if(!PART_TABS.includes(id))return;activePart=id;/* 横滑时点一下不让零件跳走：只在换标签时按「最近用过」重新排 */trays.forEach(t=>{const before=t.lastOrder;t.allowReorder=true;updateTray(t);t.allowReorder=false;if(t.rail&&t.lastOrder!==before)t.grid.scrollLeft=0});PART_TABS.forEach(x=>{const s=document.getElementById('picker-'+x);if(s)s.hidden=x!==id});document.querySelectorAll('[data-jump]').forEach(b=>{if(b.dataset.jump===id)b.setAttribute('aria-current','location');else b.removeAttribute('aria-current')});document.querySelectorAll('[data-part-tab]').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.partTab===id)));fitAll()}
// 2026-11-23 拾：零件区上面也放一排标签，免得有人没发现顶上那排能切换。这里点了只换格子，不滚动。
document.querySelectorAll('[data-part-tab]').forEach(b=>{b.setAttribute('role','tab');b.addEventListener('click',()=>{showPart(b.dataset.partTab);queueDock()})})

function card(s){
 const text=compose(s),saved=hasSaved(s),animal=ANIMALS.find(x=>x.id===animalForEar(s.ears));
 const c=el('article','puppy-card'),top=el('div','card-portrait');
 const saveBtn=button('card-save',saved?'♥':'♡',()=>save(s));
 localizedAttr(saveBtn,'aria-label',(saved?'取消收藏 ':'收藏 ')+text);
 saveBtn.setAttribute('aria-pressed',String(saved));
 const face=el('span','kaomoji card-puppy',text);
 face.dir='ltr';if(Array.from(text).length>25)face.style.fontSize='16px';
 top.append(face,saveBtn);
 const bottom=el('div','card-bottom'),animalName=animal?animal.name:'团子',a=s.accessories||{};
 const name=el('span','card-name',(a.wings?'天使':a.horns?'恶魔':PARTS.eyes[s.eyes].mood)+animalName);
 name.append(el('small','',PARTS.ears[s.ears].name));
 const actions=el('div','card-actions');
 actions.append(button('','捏捏',()=>{
  quietFace=true;change(()=>{state=cloneState(s);counter++});
  showView('studio');
  window.scrollTo(0,$('.workbench').getBoundingClientRect().top+window.scrollY-dockOffset());
 }),button('','复制',()=>takeCreature(s)));
 bottom.append(name,actions);c.append(top,bottom);return c;
}
function matches(s){
 if(filter==='全部团子')return true;
 if(filter==='新到表情')return FRESH_LOOKS.some(x=>compose(x.state)===compose(s));
 const animal=ANIMALS.find(x=>x.name===filter),a=s.accessories||{};
 if(animal)return animalForEar(s.ears)===animal.id;
 if(filter==='小恶魔')return a.horns>0;
 if(filter==='小天使')return a.wings>0;
 return PARTS.eyes[s.eyes].mood===filter;
}
function renderGallery(){replaceContents($('#gallery'),...gallery.filter(matches).slice(0,12).map(card))}
function newRandom(animalId=null,mood=null){const chosen=animalId||ANIMALS[Math.floor(Math.random()*ANIMALS.length)].id;const s=cloneState(randomAnimalState(chosen,mood));for(const k of Object.keys(ACCESSORIES))s.accessories[k]=k!=='horns'&&Math.random()<.2?1+Math.floor(Math.random()*(ACCESSORIES[k].length-1)):0;return s}
function refreshGallery(){
 const moods=['开心','撒娇','困困','委屈'];
 gallery=[...ANIMAL_LOOKS,...FRESH_LOOKS,...looks].map(look=>cloneState(look.state));
 gallery.push(cloneState(DEFAULT));
 ANIMALS.forEach(animal=>moods.forEach(mood=>gallery.push(newRandom(animal.id,mood))));
 const animal=ANIMALS.find(x=>x.name===filter),mood=moods.includes(filter)?filter:null;
 for(let i=0;i<24;i++){
  const s=newRandom(animal?animal.id:null,mood);
  if(filter==='小恶魔')s.accessories.horns=1+Math.floor(Math.random()*(ACCESSORIES.horns.length-1));
  if(filter==='小天使')s.accessories.wings=1+Math.floor(Math.random()*(ACCESSORIES.wings.length-1));
  gallery.push(s);
 }
 const seen=new Set();
 gallery=gallery.filter(s=>{
  const text=compose(s);
  if(seen.has(text))return false;
  seen.add(text);
  return true;
 });
 renderGallery();
}
function renderFilters(){
 replaceContents($('#filters'),...categories.map(name=>{
  const b=button('filter',name,()=>{filter=name;renderFilters();refreshGallery()});
  b.setAttribute('aria-pressed',String(filter===name));
  return b;
 }));
}
function renderFavorites(){
 if($('#favorites').hidden)return;
 replaceContents($('#favorite-grid'),...favorites.map(card));
 $('#empty-favorites').hidden=loadingFavorites||!!favorites.length||!$('#favorites-storage-status').hidden;
}
function showView(view){$('#studio').hidden=view!=='studio';$('#favorites').hidden=view!=='favorites';$$('.nav-item').forEach(b=>{b.classList.toggle('active',b.dataset.view===view);if(b.dataset.view===view)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current')});if(view==='favorites')renderFavorites()}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$('.brand').addEventListener('click',e=>{e.preventDefault();showView('studio');window.scrollTo(0,0)});
$$('[data-jump]').forEach(b=>b.addEventListener('click',()=>jumpToPart(b.dataset.jump)));
$('#copy').addEventListener('click',()=>takeCreature(state));
$('#copy-compact').addEventListener('click',()=>takeCreature(state));
$('#save').addEventListener('click',()=>save(state));
$('#select-copy-text').addEventListener('click',selectText);
$('#random').addEventListener('click',()=>{quietFace=true;change(()=>{state=newRandom();counter++});toast('噗叽！一只字字兽诞生啦')});
$('#reset').addEventListener('click',()=>{quietFace=true;change(()=>state=clearFace(state),{remember:false});toast('搭配已清空，点一下撤回就能找回来')});
$('#undo').addEventListener('click',()=>{if(history.length){state=history.pop();render();syncCustom()}});
$('#more').addEventListener('click',()=>{refreshGallery();toast('新的一窝团子来啦')});$('#close-dialog').addEventListener('click',()=>$('#manual-copy').close());


const mobileScreen=matchMedia('(max-width: 720px)');
let dockFrame=0;let dockFullHeight=0;
function dockOffset(){
 return mobileScreen.matches?Math.max(0,parseFloat(getComputedStyle($('#preview-dock')).top)||0):0;
}
function updateDock(){
 if($('#studio').hidden)return;
 const dock=$('#preview-dock'),workbench=$('.workbench');
 const top=dockOffset();
 dock.classList.toggle('is-compact',compactDock({mobile:mobileScreen.matches,workbenchTop:workbench.getBoundingClientRect().top-top,wasCompact:dock.classList.contains('is-compact')}));
 // 2026-11-23 界：卡片收起后会矮一截，先用 margin 把少掉的高度垫上，下面的内容就不会被一下拽上来
 const compactNow=dock.classList.contains('is-compact');
 if(!compactNow){dock.style.marginBottom='';dockFullHeight=dock.getBoundingClientRect().height}
 else if(dockFullHeight){dock.style.marginBottom=Math.max(0,dockFullHeight-dock.getBoundingClientRect().height)+'px'}
 const height=dock.getBoundingClientRect().height+top;document.documentElement.style.setProperty('--puppy-dock-height',height+'px');
 const limit=mobileScreen.matches?height+18:36;let active=null;
 active=activePart
 $$('[data-jump]').forEach(b=>{if(b.dataset.jump===active)b.setAttribute('aria-current','location');else b.removeAttribute('aria-current')});
}
function queueDock(){if(!dockFrame)dockFrame=requestAnimationFrame(()=>{dockFrame=0;updateDock()})}
function jumpToPart(id){
 const target=$('#picker-'+id);showPart(id);
 if(mobileScreen.matches){
  const dock=$('#preview-dock');
  if(!dock.classList.contains('is-compact'))dockFullHeight=dock.getBoundingClientRect().height;
  dock.classList.add('is-compact');
  if(dockFullHeight)dock.style.marginBottom=Math.max(0,dockFullHeight-dock.getBoundingClientRect().height)+'px';
 }
 const height=$('#preview-dock').getBoundingClientRect().height+dockOffset();
 const scrollTop=anchorTop(target.getBoundingClientRect().top,window.scrollY,height,mobileScreen.matches);
 target.tabIndex=-1;
 target.focus();
 window.scrollTo(0,scrollTop);
 queueDock();
}
function applyWindowInfo(info){
 const inset=topInset(info);
 const style=document.documentElement.style;
 if(inset)style.setProperty('--minitool-top',inset+'px');
 else style.removeProperty('--minitool-top');
 queueDock();
}
async function refreshWindowInfo(){
 try{applyWindowInfo(await miniTool.call('getWindowInfo',9490))}
 catch(error){}
}
function setupDock(){
 let resizeTimer;
 window.addEventListener('scroll',queueDock,{passive:true});
 window.addEventListener('resize',()=>{
  queueDock();
  clearTimeout(resizeTimer);
  resizeTimer=setTimeout(refreshWindowInfo,160);
 },{passive:true});
 if(typeof mobileScreen.addEventListener==='function')mobileScreen.addEventListener('change',queueDock);
 else mobileScreen.addListener(queueDock);
 if(typeof ResizeObserver!=='undefined')new ResizeObserver(queueDock).observe($('#preview-dock'));
 if(document.fonts&&document.fonts.ready)document.fonts.ready.then(queueDock);
 const visual=window.visualViewport;
 if(visual&&typeof visual.addEventListener==='function'){
  visual.addEventListener('resize',()=>document.documentElement.style.setProperty('--visible-height',visual.height+'px'));
 }
 miniTool.launch.then(options=>{
  const env=options&&options.miniToolEnv;
  if(env&&env.windowInfo)applyWindowInfo(env.windowInfo);
  refreshWindowInfo();
 });
 updateDock();
}

// 2026-11-23 界（拾提，照 Live2D 的思路）：「拆零件」。点颜文字，把它拆成一块块零件：
// × 删掉这一块，点进去可以改字。删掉、改过的零件会一直保持，
// 直到在下面重新选这个部件，才会被新部件覆盖。撤回照常可用。
const slotOrder=[['prefix','前装饰'],['wingLeft','左翅膀','wings'],['handLeft','左手','hands'],['left','左耳'],['hornLeft','左角','horns'],['blushLeft','左腮红'],['eyeLeft','左眼'],['mouth','嘴巴'],['eyeRight','右眼'],['blushRight','右腮红'],['hornRight','右角','horns'],['right','右耳'],['handRight','右手','hands'],['wingRight','右翅膀','wings'],['tail','尾巴','tail'],['suffix','后装饰']];
function slotDefault(key){const v=values(Object.assign({},state,{custom:{}})),a=state.accessories||{};
 if(key==='hornLeft')return ACCESSORIES.horns[a.horns||0].v[0];if(key==='hornRight')return ACCESSORIES.horns[a.horns||0].v[1];
 if(key==='wingLeft')return ACCESSORIES.wings[a.wings||0].v[0];if(key==='wingRight')return ACCESSORIES.wings[a.wings||0].v[1];
 if(key==='handLeft'||key==='handRight')return a.hands?ACCESSORIES.hands[a.hands].v[key==='handLeft'?0:1]:''
if(key==='tail')return ACCESSORIES.tail[a.tail||0].v;return v[key]==null?'':v[key]}
function slotValue(key){return hasOwn(state.custom,key)?state.custom[key]:slotDefault(key)}
const cleanSlot=v=>Array.from(v.replace(/[\u0000-\u001f\u007f‪-‮⁦-⁩]/gu,'')).slice(0,16).join('');
function earSlots(side){
 if(hasOwn(state.custom,side))return null;
 const segments=earSegments({},PARTS.ears[state.ears],side);
 if(segments[0][0]===side)return null;
 return segments.filter(([key,def])=>hasOwn(state.custom,key)||def.trim()!=='')
  .map(([key,def])=>({key,label:names[key],def}));
}
function renderSlots(){
 const box=$('#slot-list');box.textContent='';
 for(const [key,label,needs] of slotOrder){
  if(needs&&!state.accessories[needs])continue;
  if(key==='left'||key==='right'){const subs=earSlots(key);if(subs){subs.forEach(sub=>box.append(pieceChip(sub)));continue}}
  const has=hasOwn(state.custom,key),deleted=has&&state.custom[key]==='';
  if(!deleted&&!has&&slotDefault(key)==='')continue;
  const chip=el('div','slot-chip'+(deleted?' is-deleted':''));chip.append(el('small','',label));
  if(deleted){chip.append(button('slot-restore','↺ 恢复',()=>{delete state.custom[key];render();syncCustom();renderSlots()}))}
  else{const input=el('input');input.type='text';input.dir='ltr';input.value=slotValue(key);input.spellcheck=false;input.autocomplete='off';localizedAttr(input,'aria-label',label);
   input.addEventListener('input',()=>{state.custom[key]=cleanSlot(input.value);render();syncCustom()});
   const del=button('slot-delete','×',()=>{state.custom[key]='';render();syncCustom();renderSlots()});localizedAttr(del,'aria-label','删掉'+label);
   chip.append(input,del)}
  box.append(chip)}
}
function openSlots(){checkpoint();render();renderSlots();$('#slot-edit').showModal()}
$('#puppy').addEventListener('click',openSlots);
$('#puppy').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openSlots()}});
$('#slot-open').addEventListener('click',openSlots);
$('#slot-open-compact').addEventListener('click',openSlots);
$('#slot-done').addEventListener('click',()=>{$('#slot-edit').close();render();toast('拆好啦，删掉的零件会一直保持')});

let cardOpening=false,cardExporting=false;
async function openShare(s){
 if(cardOpening||$('#share-card').open)return;
 const text=compose(s);
 const t=x=>translate(x,language);
 const caption=s===state?$('#puppy-caption').textContent:t('这一只，是你的独家字字兽');
 cardOpening=true;
 try{
  await drawShareCard($('#share-img'),text,caption,{
   brand:t('字字兽 · 颜文字团子工厂'),
   tagline:t('在小红书搜「字字兽」，捏一只你的团子')
  });
  const available=await Promise.all([
   miniTool.supports('saveImageToPhotosAlbum',9420),
   miniTool.supports('share',9530)
  ]);
  $('#share-save').hidden=!available[0];
  $('#share-native').hidden=!available[1];
  $('#share-unavailable').hidden=available[0]||available[1];
  setText($('#share-action-status'),'');
  $('#share-card').showModal();
 }catch(error){
  toast('卡片生成失败了，再试一次吧');
 }finally{
  cardOpening=false;
 }
}
async function exportCard(saveToAlbum){
 if(cardExporting)return;
 cardExporting=true;
 const controls=[$('#share-save'),$('#share-native')];
 controls.forEach(control=>control.disabled=true);
 const status=$('#share-action-status');
 setText(status,'');
 try{
  let image=$('#share-img').toDataURL('image/png');
  const version=saveToAlbum?9420:9530;
  if(image.length>138000&&await miniTool.supports('writeTempFile',version)){
   const file=await miniTool.call('writeTempFile',version,{data:image});
   if(typeof file.filePath==='string'&&file.filePath)image=file.filePath;
  }
  if(saveToAlbum){
   await miniTool.call('saveImageToPhotosAlbum',9420,{filePath:image},15000);
   setText(status,'已保存到相册');
  }else{
   await miniTool.call('share',9530,{type:'image',image_resource:image},15000);
  }
 }catch(error){
  const message=saveToAlbum?'保存到相册未确认，请检查权限后再试'
   :error&&error.errCode===15502?'请在小红书全屏打开后分享'
   :'暂时无法分享，可以稍后再试';
  setText(status,message);
 }finally{
  controls.forEach(control=>control.disabled=false);
  cardExporting=false;
 }
}
$('#share-open').addEventListener('click',()=>openShare(state));
$('#text-card').addEventListener('click',()=>{
 $('#manual-copy').close();
 openShare(selectedOutput);
});
$('#share-save').addEventListener('click',()=>exportCard(true));
$('#share-native').addEventListener('click',()=>exportCard(false));
$('#share-close').addEventListener('click',()=>$('#share-card').close());

// 拆开的耳朵块：保留原来那一块前后的空格，只换中间的字
function pieceChip({key,label,def}){
 const has=hasOwn(state.custom,key),deleted=has&&state.custom[key]==='';
 const lead=def.match(/^\s*/u)[0],trail=def.match(/\s*$/u)[0];
 const chip=el('div','slot-chip'+(deleted?' is-deleted':''));chip.append(el('small','',label));
 if(deleted){chip.append(button('slot-restore','↺ 恢复',()=>{delete state.custom[key];render();syncCustom();renderSlots()}));return chip}
 const input=el('input');input.type='text';input.dir='ltr';input.value=(has?state.custom[key]:def).trim();input.spellcheck=false;input.autocomplete='off';localizedAttr(input,'aria-label',label);
 input.addEventListener('input',()=>{const v=cleanSlot(input.value).trim();state.custom[key]=v?lead+v+trail:'';render();syncCustom()});
 const del=button('slot-delete','×',()=>{state.custom[key]='';render();syncCustom();renderSlots()});localizedAttr(del,'aria-label','删掉'+label);
 chip.append(input,del);return chip}

async function loadLanguage(){
 const record=await preferences.read(LANGUAGE_KEY,value=>value==='zh'||value==='en');
 if(record.ok&&record.value&&!languageChanged){
  language=record.value;
  applyLanguage();
 }
 return record.ok;
}
function detectFlexGap(){
 const probe=el('div');
 probe.style.cssText='position:absolute;visibility:hidden;display:flex;flex-direction:column;row-gap:1px';
 probe.append(el('div'),el('div'));
 document.body.append(probe);
 document.documentElement.classList.toggle('has-flex-gap',probe.scrollHeight===1);
 probe.remove();
}
function boot(){
 detectFlexGap();
 bindStaticText();
 buildControls();
 render();
 syncCustom();
 showView('studio');
 setupDock();
 applyLanguage();
 favoritesReady=loadFavorites();
 recentReady=loadRecent();
 const languageReady=loadLanguage();
 $$('[data-language]').forEach(button=>button.addEventListener('click',async()=>{
  const chosen=button.dataset.language;
  languageChanged=true;
  language=chosen;
  applyLanguage();
  const ready=await languageReady;
  if(language===chosen&&(!ready||!await preferences.write(LANGUAGE_KEY,chosen))){
   toast('本次语言已切换，偏好暂未保存');
  }
 }));
 $$('[data-startup-control]').forEach(control=>control.disabled=false);
 $('#startup-status').hidden=true;
 requestAnimationFrame(()=>setTimeout(()=>{
  renderFilters();
  refreshGallery();
 },0));
}
boot();

}());
}());
